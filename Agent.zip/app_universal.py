﻿import os
import sys
import io
import csv
import json
import time
import random
import tempfile
import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SRC_DIR = os.path.join(BASE_DIR, "src")
DATA_DIR = os.path.join(BASE_DIR, "data")
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)

from dotenv import load_dotenv
from google import genai
from google.genai import types
import streamlit as st
import streamlit.components.v1 as components

from universal_schema import UniversalVideoAnalysisResult
from adaptive_video_splitter import generate_standard_clips_zip
from key_manager import key_pool
from knowledge_graph_rag import kg_rag_engine
from graph_visualizer import generate_interactive_graph_html, generate_single_video_graph_html

st.set_page_config(page_title="2-Tier Agentic Hub (EduViolence AI)", layout="wide", page_icon="🛡️")

load_dotenv(os.path.join(BASE_DIR, ".env"), encoding="utf-8-sig")

FIXED_VLM_MODEL = "gemini-flash-latest"
FALLBACK_MODELS = ["gemini-2.0-flash", "gemini-2.0-flash-lite"]
MAX_VLM_RETRIES = 8
BACKOFF_BASE_SECONDS = 8


def get_backoff_time(attempt, base=BACKOFF_BASE_SECONDS):
    wait = base * (2 ** (attempt - 1))
    jitter = random.uniform(0, wait * 0.25)
    return min(wait + jitter, 120)


def call_vlm_with_smart_retry(contents, use_schema=True, status_container=None):
    all_models = [FIXED_VLM_MODEL] + FALLBACK_MODELS

    for attempt in range(1, MAX_VLM_RETRIES + 1):
        curr_key = key_pool.get_next_available_key()

        if attempt <= 4:
            current_model = all_models[0]
        elif attempt <= 6:
            current_model = all_models[1] if len(all_models) > 1 else all_models[0]
        else:
            current_model = all_models[2] if len(all_models) > 2 else all_models[-1]

        client = genai.Client(api_key=curr_key)
        masked_key = curr_key[:6] + "..." + curr_key[-4:]

        if status_container:
            status_container.write(
                f"🧠 [Thử {attempt}/{MAX_VLM_RETRIES}] Model `{current_model}` | Key `{masked_key}`..."
            )

        try:
            config = types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=UniversalVideoAnalysisResult
            ) if use_schema else None

            response = client.models.generate_content(
                model=current_model,
                contents=contents,
                config=config
            )
            return response, current_model

        except Exception as e:
            err_msg = str(e)

            if any(k in err_msg for k in ["503", "UNAVAILABLE", "overloaded", "currently exp"]):
                key_pool.mark_rate_limited(curr_key, cooldown_seconds=60)
                wait = get_backoff_time(attempt)
                if status_container:
                    status_container.write(f"  ⚠️ 503 Model quá tải. Xoay key + chờ {wait:.0f}s...")
                time.sleep(wait)

            elif any(k in err_msg for k in ["429", "RESOURCE_EXHAUSTED", "Quota"]):
                key_pool.mark_rate_limited(curr_key, cooldown_seconds=30)
                wait = get_backoff_time(attempt)
                if status_container:
                    status_container.write(f"  ⚠️ 429 Rate Limit. Xoay key + chờ {wait:.0f}s...")
                time.sleep(wait)

            elif any(k in err_msg for k in ["403", "PERMISSION_DENIED", "API_KEY_INVALID", "401"]):
                key_pool.mark_dead(curr_key)
                if status_container:
                    status_container.write(f"  🚫 Key `{masked_key}` bị vô hiệu hóa.")

            else:
                wait = min(5 * attempt, 30)
                if status_container:
                    status_container.write(f"  ⚠️ Lỗi: {err_msg[:100]}. Chờ {wait}s...")
                time.sleep(wait)

    return None, None


ACTION_ID_MAP = {
    "Punching": "A01", "Kicking": "A02", "Slapping": "A03", "Pushing/Shoving": "A04",
    "Hair pulling": "A05", "Wrestling down / Throwing to the ground": "A06",
    "Group fighting / Mob beating": "A07", "Threatening with a dangerous weapon": "A08",
    "Walking": "A09", "Jogging / Running": "A10", "Standing still": "A11",
    "Sitting": "A12", "Playing sports": "A13", "Handshaking": "A14",
    "Peaceful gathering": "A15", "Dancing": "A16"
}

DATASET_CONFIGS = {
    "🥊 Đấm (Punching)": {"json": os.path.join(DATA_DIR, "report_Punching.json"), "video_dir": r"E:\test\Punching", "key": "Punching"},
    "🦵 Đá (Kicking)": {"json": os.path.join(DATA_DIR, "report_Kicking.json"), "video_dir": r"E:\test\Kicking", "key": "Kicking"},
    "✋ Tát (Slapping)": {"json": os.path.join(DATA_DIR, "report_Slapping.json"), "video_dir": r"E:\test\Slapping", "key": "Slapping"},
    "🫸 Xô đẩy / Giằng co (Pushing/Shoving)": {"json": os.path.join(DATA_DIR, "report_Pushing_Shoving.json"), "video_dir": r"E:\test\Pushing or Shoving", "key": "Pushing"},
    "💇 Giật / Kéo tóc (Hair pulling)": {"json": os.path.join(DATA_DIR, "report_Hair_pulling.json"), "video_dir": r"E:\test\Hair pulling", "key": "Hair"},
    "🤼 Quật ngã / Vật ngã (Wrestling down)": {"json": os.path.join(DATA_DIR, "report_Wrestling_down.json"), "video_dir": r"E:\test\Wrestling down or Throwing to the ground", "key": "Wrestling"},
    "⚠️ Đánh hội đồng (Group fighting)": {"json": os.path.join(DATA_DIR, "report_Group_fighting.json"), "video_dir": r"E:\test\Group fighting or Mob beating", "key": "Group"},
    "🚨 Cầm hung khí đe dọa (Threatening weapon)": {"json": os.path.join(DATA_DIR, "report_Threatening_weapon.json"), "video_dir": r"E:\test\Threatening with a dangerous weapon", "key": "Threatening"},
    "🚶 Đi bộ (Walking)": {"json": os.path.join(DATA_DIR, "report_Walking.json"), "video_dir": r"E:\test\Walking", "key": "Walking"},
    "🏃 Chạy bộ / Chạy (Jogging / Running)": {"json": os.path.join(DATA_DIR, "report_Jogging_Running.json"), "video_dir": r"E:\test\Jogging or Running", "key": "Jogging"},
    "🧍 Đứng yên (Standing still)": {"json": os.path.join(DATA_DIR, "report_Standing_still.json"), "video_dir": r"E:\test\Standing still", "key": "Standing"},
    "🪑 Ngồi (Sitting)": {"json": os.path.join(DATA_DIR, "report_Sitting.json"), "video_dir": r"E:\test\Sitting", "key": "Sitting"},
    "⚽ Hoạt động Thể thao (Playing sports)": {"json": os.path.join(DATA_DIR, "report_Playing_sports.json"), "video_dir": r"E:\test\Playing sports", "key": "Playing"},
    "🤝 Bắt tay / Nắm tay (Handshaking)": {"json": os.path.join(DATA_DIR, "report_Handshaking.json"), "video_dir": r"E:\test\Handshaking", "key": "Handshaking"},
    "👥 Tụ tập ôn hòa (Peaceful gathering)": {"json": os.path.join(DATA_DIR, "report_Peaceful_gathering.json"), "video_dir": r"E:\test\Peaceful gathering", "key": "Peaceful"},
    "💃 Nhảy múa / Khiêu vũ (Dancing)": {"json": os.path.join(DATA_DIR, "report_Dancing.json"), "video_dir": r"E:\test\Dancing", "key": "Dancing"}
}

CATEGORY_MAPPING_16 = {
    "Punching": "🥊 Đấm (Punching)", "Kicking": "🦵 Đá (Kicking)", "Slapping": "✋ Tát (Slapping)",
    "Pushing/Shoving": "🫸 Xô đẩy / Giằng co (Pushing/Shoving)", "Hair pulling": "💇 Giật / Kéo tóc (Hair pulling)",
    "Wrestling down / Throwing to the ground": "🤼 Quật ngã / Vật ngã (Wrestling down)",
    "Group fighting / Mob beating": "⚠️ Đánh hội đồng (Group fighting)",
    "Threatening with a dangerous weapon": "🚨 Cầm hung khí đe dọa (Threatening weapon)",
    "Walking": "🚶 Đi bộ (Walking)", "Jogging / Running": "🏃 Chạy bộ / Chạy (Jogging / Running)",
    "Standing still": "🧍 Đứng yên (Standing still)", "Sitting": "🪑 Ngồi (Sitting)",
    "Playing sports": "⚽ Hoạt động Thể thao (Playing sports)", "Handshaking": "🤝 Bắt tay / Nắm tay (Handshaking)",
    "Peaceful gathering": "👥 Tụ tập ôn hòa (Peaceful gathering)", "Dancing": "💃 Nhảy múa / Khiêu vũ (Dancing)"
}

def find_actual_video_path(filename):
    for item in DATASET_CONFIGS.values():
        target = os.path.join(item["video_dir"], filename)
        if os.path.exists(target):
            return target
    return None

def get_video_properties(v_path):
    if not v_path or not os.path.exists(v_path):
        return {"fps": 25.0, "resolution": "640x360", "duration_s": 10.0}
    try:
        cap = cv2.VideoCapture(v_path)
        fps = round(cap.get(cv2.CAP_PROP_FPS) or 25.0, 1)
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total_f = cap.get(cv2.CAP_PROP_FRAME_COUNT)
        dur = round(total_f / fps, 1) if fps > 0 else 10.0
        cap.release()
        return {"fps": fps, "resolution": f"{w}x{h}", "duration_s": dur}
    except Exception:
        return {"fps": 25.0, "resolution": "640x360", "duration_s": 10.0}

def extract_uniform_keyframes(video_path, num_frames=12):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened(): return []
    total_f = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    if total_f <= 0:
        cap.release()
        return []
    frame_indices = [int(i * total_f / num_frames) for i in range(num_frames)]
    parts = []
    for f_idx in frame_indices:
        cap.set(cv2.CAP_PROP_POS_FRAMES, f_idx)
        ret, frame = cap.read()
        if not ret: continue
        resized = cv2.resize(frame, (480, 270))
        _, buffer = cv2.imencode('.jpg', resized, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
        timestamp_sec = f_idx / fps if fps > 0 else 0.0
        time_str = f"{int(timestamp_sec//60):02d}:{int(timestamp_sec%60):02d}"
        parts.append(f"--- Mốc thời gian: {time_str} ---")
        parts.append(types.Part.from_bytes(data=buffer.tobytes(), mime_type="image/jpeg"))
    cap.release()
    return parts
import subprocess
def extract_montage_grid(video_path, num_samples=6):
    """Tạo lưới Montage 2x3 giống batch — tiết kiệm token, nhanh hơn 3x."""
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return None, 0.0
    
    total_f = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    duration = total_f / fps if fps > 0 else 10.0
    
    if total_f <= 0:
        cap.release()
        return None, duration

    step = max(1, total_f // num_samples)
    selected_frames = []
    timestamps = []

    for i in range(num_samples):
        target_frame = min(int(i * step + step // 2), total_f - 1)
        cap.set(cv2.CAP_PROP_POS_FRAMES, target_frame)
        ret, frame = cap.read()
        if not ret:
            break

        resized = cv2.resize(frame, (480, 270))
        t_sec = target_frame / fps
        time_tag = f"[{int(t_sec//60):02d}:{int(t_sec%60):02d}]"
        timestamps.append(time_tag)

        # Gắn nhãn thời gian lên ảnh
        cv2.rectangle(resized, (5, 5), (105, 30), (0, 0, 0), -1)
        cv2.putText(resized, time_tag, (8, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 255, 255), 2)
        selected_frames.append(resized)

    cap.release()

    if len(selected_frames) < 3:
        return None, duration

    # Pad nếu không đủ 6 frames
    while len(selected_frames) < 6:
        selected_frames.append(selected_frames[-1].copy())

    row1 = np.hstack(selected_frames[:3])
    row2 = np.hstack(selected_frames[3:6])
    montage = np.vstack([row1, row2])

    _, buffer = cv2.imencode('.jpg', montage, [int(cv2.IMWRITE_JPEG_QUALITY), 85])
    
    montage_part = types.Part.from_bytes(data=buffer.tobytes(), mime_type="image/jpeg")
    time_info = f"Lưới 2×3 gồm 6 mốc thời gian: {', '.join(timestamps[:6])}"
    
    return [time_info, montage_part], duration
def extract_audio_from_video(video_path, max_duration=30):
    """Trích xuất audio từ video thành WAV bytes bằng ffmpeg."""
    try:
        audio_tmp = video_path + "_audio.wav"
        cmd = [
            "ffmpeg", "-y", "-i", video_path,
            "-vn", "-acodec", "pcm_s16le", "-ar", "16000", "-ac", "1",
            "-t", str(max_duration),
            audio_tmp
        ]
        result = subprocess.run(cmd, capture_output=True, timeout=30)
        
        if result.returncode == 0 and os.path.exists(audio_tmp):
            with open(audio_tmp, "rb") as f:
                audio_bytes = f.read()
            os.remove(audio_tmp)
            if len(audio_bytes) > 1000:  # Kiểm tra audio có nội dung
                return audio_bytes
        
        # Cleanup nếu lỗi
        if os.path.exists(audio_tmp):
            os.remove(audio_tmp)
        return None
    except Exception:
        return None
def analyze_audio_with_vlm(audio_bytes, status_container=None):
    """Phân tích audio bằng Gemini VLM, trả về dict kết quả."""
    audio_prompt = """
BẠN LÀ: Chuyên gia Phân tích Âm thanh Học đường (EduViolence AI - Audio Module).

NHIỆM VỤ: Phân tích đoạn audio trích xuất từ video giám sát trường học.

Hãy trả lời bằng Tiếng Việt theo cấu trúc sau:

## 🔊 PHÂN LOẠI ÂM THANH TỔNG THỂ
- **Loại môi trường:** Yên tĩnh / Ồn ào nhẹ / Ồn ào / Hỗn loạn
- **Mức cảnh báo âm thanh:** An toàn / Đáng chú ý / Nguy hiểm / Khẩn cấp

## 🎯 CÁC ÂM THANH PHÁT HIỆN ĐƯỢC
Liệt kê từng âm thanh đáng chú ý:

| # | Thời điểm (ước lượng) | Loại âm thanh | Mô tả chi tiết | Mức nguy hiểm |
|---|----------------------|---------------|-----------------|---------------|
| 1 | ?s - ?s | ? | ? | Thấp/TB/Cao |

Các loại âm thanh cần chú ý:
- 🗣️ **Giọng nói:** Nói chuyện bình thường / La hét / Chửi bới / Cầu cứu / Khóc
- 💥 **Va chạm:** Tiếng đấm/đá / Tiếng ngã / Tiếng vật thể va đập
- 🔔 **Cảnh báo:** Còi báo động / Tiếng huýt sáo / Tiếng gọi giúp đỡ
- 🎵 **Nền:** Nhạc / Tiếng bước chân / Gió / Im lặng

## 👥 PHÂN TÍCH GIỌNG NÓI (nếu có)
- Số người nói ước đoán: ?
- Giọng nam/nữ/trẻ em: ?
- Cảm xúc trong giọng nói: Bình tĩnh / Tức giận / Sợ hãi / Đau đớn
- Có nội dung đe dọa/xúc phạm không: Có/Không

## ⚡ KẾT LUẬN AUDIO
- **Âm thanh hỗ trợ giả thuyết bạo lực?:** Có / Không / Không rõ
- **Bằng chứng âm thanh mạnh nhất:** Mô tả ngắn gọn
- **Độ tin cậy phân tích audio:** Cao / Trung bình / Thấp (giải thích lý do)
"""

    if status_container:
        status_container.write("🔊 Đang phân tích audio bằng VLM...")

    audio_part = types.Part.from_bytes(data=audio_bytes, mime_type="audio/wav")
    response, used_model = call_vlm_with_smart_retry(
        contents=[audio_part, audio_prompt],
        use_schema=False,
        status_container=status_container
    )

    if response:
        if status_container:
            status_container.write(f"✅ Audio analysis hoàn tất! ({used_model})")
        return response.text
    return None
def get_adaptive_num_frames(video_path):
    """Tự động chọn số keyframe dựa trên độ dài video."""
    try:
        cap = cv2.VideoCapture(video_path)
        fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
        total_frames = cap.get(cv2.CAP_PROP_FRAME_COUNT)
        duration = total_frames / fps if fps > 0 else 10.0
        cap.release()
        if duration <= 5:
            return 6, duration
        elif duration <= 15:
            return 12, duration
        else:
            return 24, duration
    except Exception:
        return 12, 10.0


def parse_time_to_sec(time_str):
    """Chuyển '00:03' hoặc '00:03.5' thành số giây."""
    try:
        parts = time_str.replace(".", ":").split(":")
        if len(parts) >= 2:
            return int(parts[0]) * 60 + float(parts[1])
        return float(parts[0])
    except Exception:
        return 0.0


def generate_event_timeline_html(timeline_events, video_duration, height=160):
    """Timeline nâng cấp v3: rộng, rõ ràng, dễ đọc."""
    if not timeline_events or video_duration <= 0:
        return "<div style='color:#94a3b8;padding:12px;text-align:center;'>Không có dữ liệu timeline.</div>"

    total_sec = max(video_duration, 1)

    # Parse events
    events_parsed = []
    actors_set = {}
    action_counts = {}
    total_danger = 0

    for ev in timeline_events:
        start_s = parse_time_to_sec(ev.get("start_time") or "00:00")
        end_s = parse_time_to_sec(ev.get("end_time") or "00:01")
        if end_s <= start_s:
            end_s = start_s + 1
        total_sec = max(total_sec, end_s + 0.5)

        force = ev.get("force_intensity") or "Trung bình"
        action = (ev.get("action_label") or "?")[:22]
        actor = ev.get("actor_id") or "Person_01"
        target = ev.get("target_id") or ""
        weapon = ev.get("body_part_or_weapon") or "Tay không"
        contact = ev.get("target_contact_point") or ""
        impact = (ev.get("physical_impact") or "")[:60]

        if "Mạnh" in force or "Nguy hiểm" in force:
            color = "#ef4444"; border_c = "#fca5a5"; danger_val = 3; force_icon = "🔴"
        elif "Trung bình" in force:
            color = "#f59e0b"; border_c = "#fcd34d"; danger_val = 2; force_icon = "🟡"
        else:
            color = "#10b981"; border_c = "#6ee7b7"; danger_val = 1; force_icon = "🟢"

        if actor not in actors_set:
            if "Aggressor" in actor:
                actors_set[actor] = {"color": "#dc2626", "icon": "🥊", "role": "Kẻ tấn công"}
            elif "Victim" in actor:
                actors_set[actor] = {"color": "#3b82f6", "icon": "🛡️", "role": "Nạn nhân"}
            elif "Intervener" in actor:
                actors_set[actor] = {"color": "#06b6d4", "icon": "👮", "role": "Can ngăn"}
            else:
                actors_set[actor] = {"color": "#8b5cf6", "icon": "👤", "role": "Người"}

        total_danger += danger_val
        action_counts[action] = action_counts.get(action, 0) + 1

        events_parsed.append({
            "start": start_s, "end": end_s,
            "action": action, "force": force, "color": color,
            "border": border_c, "danger": danger_val, "force_icon": force_icon,
            "actor": actor, "target": target, "weapon": weapon,
            "contact": contact, "impact": impact
        })

    if not events_parsed:
        return "<div style='color:#94a3b8;padding:12px;'>Không có sự kiện.</div>"

    num_events = len(events_parsed)
    dominant_action = max(action_counts, key=action_counts.get) if action_counts else "N/A"
    avg_danger = total_danger / num_events if num_events > 0 else 0
    actor_list = list(actors_set.keys())

    # ===== SWIM LANE EVENTS =====
    lane_height = 44
    swim_lanes_html = ""
    for actor_name in actor_list:
        actor_info = actors_set[actor_name]
        actor_events = [e for e in events_parsed if e["actor"] == actor_name]
        if not actor_events:
            continue

        events_html = ""
        for ev in actor_events:
            left = (ev["start"] / total_sec) * 100
            width = max(((ev["end"] - ev["start"]) / total_sec) * 100, 6)
            time_label = f"{ev['start']:.0f}s-{ev['end']:.0f}s"

            events_html += f"""
            <div class="s-ev" style="left:{left:.1f}%;width:{width:.1f}%;background:{ev['color']};border:2px solid {ev['border']};"
                 title="{ev['force_icon']} {ev['action']}&#10;⏱️ {time_label}&#10;💪 Lực: {ev['force']}&#10;🔪 {ev['weapon']}&#10;🎯 {ev['contact']}&#10;💥 {ev['impact']}">
                <div class="s-ev-time">{time_label}</div>
                <div class="s-ev-name">{ev['force_icon']} {ev['action']}</div>
            </div>"""

        swim_lanes_html += f"""
        <div class="s-lane">
            <div class="s-label" style="border-left:4px solid {actor_info['color']};background:linear-gradient(90deg,{actor_info['color']}15,transparent);">
                <span class="s-icon">{actor_info['icon']}</span>
                <span class="s-name">{actor_name}</span>
            </div>
            <div class="s-track">{events_html}</div>
        </div>"""

    # ===== TIME AXIS (max 8 markers) =====
    num_marks = min(max(int(total_sec), 2), 8)
    marks_html = ""
    for i in range(num_marks + 1):
        t = (i / num_marks) * total_sec
        left = (i / num_marks) * 100
        m = int(t // 60)
        s = int(t % 60)
        label = f"{m:02d}:{s:02d}"
        marks_html += f'<div class="t-m" style="left:{left:.1f}%"><div class="t-line"></div><span>{label}</span></div>'

    # ===== DENSITY (mini heatmap) =====
    num_seg = min(max(int(total_sec * 2), 6), 40)
    seg_dur = total_sec / num_seg
    density = [0.0] * num_seg
    for ev in events_parsed:
        for s in range(num_seg):
            ss = s * seg_dur
            se = (s + 1) * seg_dur
            if ev["start"] < se and ev["end"] > ss:
                overlap = min(ev["end"], se) - max(ev["start"], ss)
                density[s] += ev["danger"] * (overlap / seg_dur)
    max_den = max(density) if max(density) > 0 else 1
    peak_s = density.index(max(density))
    peak_start = peak_s * seg_dur
    peak_end = (peak_s + 1) * seg_dur

    den_bars = ""
    for s in range(num_seg):
        norm = density[s] / max_den
        if norm >= 0.7: c = "#ef4444"
        elif norm >= 0.35: c = "#f59e0b"
        elif norm >= 0.1: c = "#3b82f6"
        else: c = "#1a2744"
        h = max(norm * 100, 3)
        l = (s / num_seg) * 100
        w = (1 / num_seg) * 100
        den_bars += f'<div class="d-b" style="left:{l:.1f}%;width:{w:.1f}%;height:{h:.0f}%;background:{c};"></div>'

    return f"""
    <div style="background:linear-gradient(135deg,#080c14,#0f172a);border:1px solid #1e293b;border-radius:12px;padding:18px 20px;font-family:'Segoe UI',system-ui,sans-serif;">
    <style>
        .tl-head {{ display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; flex-wrap:wrap; gap:8px; }}
        .tl-t {{ color:#e2e8f0; font-size:15px; font-weight:800; }}
        .tl-st {{ display:flex; gap:20px; }}
        .tl-s {{ text-align:center; min-width:55px; }}
        .tl-sv {{ color:#f8fafc; font-size:20px; font-weight:900; line-height:1.1; }}
        .tl-sl {{ color:#64748b; font-size:9px; text-transform:uppercase; letter-spacing:0.5px; }}

        .s-lane {{ display:flex; align-items:stretch; margin-bottom:4px; }}
        .s-label {{
            width:140px; min-width:140px; padding:8px 12px;
            display:flex; align-items:center; gap:6px;
            background:#0f172a; border-radius:6px 0 0 6px;
        }}
        .s-icon {{ font-size:16px; }}
        .s-name {{ font-size:12px; font-weight:700; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }}
        .s-track {{
            flex:1; position:relative; height:{lane_height}px; background:#111827;
            border-radius:0 6px 6px 0; overflow:hidden; border:1px solid #1e293b;
        }}
        .s-ev {{
            position:absolute; top:3px; height:{lane_height - 6}px; border-radius:6px;
            display:flex; flex-direction:column; justify-content:center; align-items:center;
            padding:2px 6px; cursor:pointer; transition:all 0.2s;
            box-shadow:0 2px 8px rgba(0,0,0,0.5);
        }}
        .s-ev:hover {{ transform:scale(1.05); z-index:20; box-shadow:0 0 20px rgba(255,255,255,0.3); filter:brightness(1.2); }}
        .s-ev-time {{ font-size:9px; color:rgba(255,255,255,0.8); font-weight:600; }}
        .s-ev-name {{ font-size:11px; color:#fff; font-weight:800; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:100%; }}

        .t-axis {{ position:relative; height:28px; margin:10px 0 10px 140px; border-top:1px solid #334155; }}
        .t-m {{ position:absolute; top:0; transform:translateX(-50%); text-align:center; }}
        .t-line {{ width:1px; height:8px; background:#475569; margin:0 auto 3px; }}
        .t-m span {{ font-size:11px; color:#94a3b8; font-weight:600; }}

        .den-sec {{ margin-top:6px; }}
        .den-head {{ display:flex; justify-content:space-between; align-items:center; margin:0 0 6px 140px; }}
        .den-t {{ color:#94a3b8; font-size:12px; font-weight:700; }}
        .den-p {{ color:#ef4444; font-size:12px; font-weight:800; }}
        .den-track {{ position:relative; height:36px; background:#0f172a; border-radius:6px; overflow:hidden; margin-left:140px; display:flex; align-items:flex-end; border:1px solid #1e293b; }}
        .d-b {{ position:absolute; bottom:0; border-radius:2px 2px 0 0; opacity:0.9; transition:all 0.2s; }}
        .d-b:hover {{ opacity:1; filter:brightness(1.3); }}

        .tl-legend {{ display:flex; gap:16px; margin:10px 0 0 140px; }}
        .tl-lg {{ display:flex; align-items:center; gap:5px; font-size:10px; color:#94a3b8; }}
        .tl-ld {{ width:12px; height:12px; border-radius:3px; }}
    </style>

    <div class="tl-head">
        <div class="tl-t">⏱️ TIMELINE SỰ KIỆN ({total_sec:.1f}s)</div>
        <div class="tl-st">
            <div class="tl-s"><div class="tl-sv">{num_events}</div><div class="tl-sl">Sự kiện</div></div>
            <div class="tl-s"><div class="tl-sv">{len(actor_list)}</div><div class="tl-sl">Thực thể</div></div>
            <div class="tl-s"><div class="tl-sv" style="color:{'#ef4444' if avg_danger>=2 else '#10b981'}">{avg_danger:.1f}/3</div><div class="tl-sl">Nguy hiểm</div></div>
            <div class="tl-s"><div class="tl-sv" style="font-size:14px;">{dominant_action[:14]}</div><div class="tl-sl">Chủ đạo</div></div>
        </div>
    </div>

    {swim_lanes_html}

    <div class="t-axis">{marks_html}</div>

    <div class="den-sec">
        <div class="den-head">
            <div class="den-t">🔥 MẬT ĐỘ</div>
            <div class="den-p">▲ Đỉnh: {peak_start:.0f}s - {peak_end:.0f}s</div>
        </div>
        <div class="den-track">{den_bars}</div>
    </div>

    <div class="tl-legend">
        <div class="tl-lg"><div class="tl-ld" style="background:#ef4444;"></div>Mạnh</div>
        <div class="tl-lg"><div class="tl-ld" style="background:#f59e0b;"></div>Trung bình</div>
        <div class="tl-lg"><div class="tl-ld" style="background:#10b981;"></div>Nhẹ</div>
    </div>

    </div>
    """
def generate_violence_density_html(timeline_events, video_duration):
    """Phân tích mật độ bạo lực nâng cao: đa chiều, phát hiện pha leo thang, điểm nóng."""
    if not timeline_events or video_duration <= 0:
        return "<div style='color:#94a3b8;padding:12px;text-align:center;'>Không có dữ liệu.</div>"

    total_sec = max(video_duration, 1)

    # ===== TRỌNG SỐ NGUY HIỂM ĐA CHIỀU =====
    WEAPON_WEIGHT = {
        "tay không": 1.0, "tay phải": 1.0, "tay trái": 1.0,
        "chân": 1.3, "chân phải": 1.3, "chân trái": 1.3,
        "gậy": 2.5, "gậy gỗ": 2.5, "dao": 3.0, "kéo": 2.8,
        "ghế": 2.2, "chai": 2.0, "đá": 2.0, "cặp sách": 1.5,
    }
    CONTACT_WEIGHT = {
        "vùng mặt": 2.5, "vùng đầu": 2.5, "mặt": 2.5, "đầu": 2.5,
        "thái dương": 3.0, "mắt": 3.0, "mũi": 2.5, "cổ": 2.8,
        "ngực": 1.8, "bụng": 1.8, "sườn": 1.6,
        "lưng": 1.3, "vai": 1.2, "gáy": 2.2,
        "chân": 1.0, "đùi": 1.0, "toàn thân": 1.5,
    }
    FORCE_WEIGHT = {"Nhẹ": 1.0, "Trung bình": 2.0, "Mạnh": 3.5, "Mạnh / Nguy hiểm": 4.0, "Nguy hiểm": 4.0}

    # ===== PARSE + SCORING TỪNG EVENT =====
    events_scored = []
    for ev in timeline_events:
        start_s = parse_time_to_sec(ev.get("start_time", "00:00"))
        end_s = parse_time_to_sec(ev.get("end_time", "00:01"))
        if end_s <= start_s:
            end_s = start_s + 1
        total_sec = max(total_sec, end_s + 0.5)

        force = ev.get("force_intensity") or "Trung bình"
        weapon = (ev.get("body_part_or_weapon") or "Tay không").lower()
        contact = (ev.get("target_contact_point") or "Toàn thân").lower()
        actor = ev.get("actor_id") or "Person_01"
        target = ev.get("target_id") or ""
        action = ev.get("action_label") or ""

        # Tính điểm nguy hiểm đa chiều
        f_score = FORCE_WEIGHT.get(force, 2.0)
        w_score = 1.0
        for wk, wv in WEAPON_WEIGHT.items():
            if wk in weapon:
                w_score = max(w_score, wv)
                break
        c_score = 1.0
        for ck, cv in CONTACT_WEIGHT.items():
            if ck in contact:
                c_score = max(c_score, cv)
                break

        # Bonus: có nạn nhân rõ ràng = nguy hiểm hơn
        target_bonus = 1.3 if target and "Victim" in target else 1.0
        # Bonus: nhóm tấn công
        group_bonus = 1.5 if "Group" in actor else 1.0

        danger_score = f_score * w_score * c_score * target_bonus * group_bonus

        events_scored.append({
            "start": start_s, "end": end_s,
            "danger": danger_score,
            "force": force, "weapon": weapon, "contact": contact,
            "action": action, "actor": actor, "target": target,
            "f_score": f_score, "w_score": w_score, "c_score": c_score,
        })

    # ===== DENSITY CURVE (mịn hơn) =====
    num_segments = min(max(int(total_sec * 3), 10), 80)
    seg_dur = total_sec / num_segments
    density = [0.0] * num_segments

    for ev in events_scored:
        for s in range(num_segments):
            seg_start = s * seg_dur
            seg_end = (s + 1) * seg_dur
            if ev["start"] < seg_end and ev["end"] > seg_start:
                overlap = min(ev["end"], seg_end) - max(ev["start"], seg_start)
                density[s] += ev["danger"] * (overlap / seg_dur)

    max_d = max(density) if max(density) > 0 else 1

    # ===== PHÁT HIỆN PHA (Escalation / Peak / De-escalation) =====
    phases = []
    smoothed = []
    window = max(num_segments // 8, 2)
    for i in range(num_segments):
        left_b = max(0, i - window)
        right_b = min(num_segments, i + window + 1)
        smoothed.append(sum(density[left_b:right_b]) / (right_b - left_b))

    max_smooth = max(smoothed) if max(smoothed) > 0 else 1
    DANGER_THRESHOLD = max_smooth * 0.25

    in_danger = False
    zone_start = 0
    danger_zones = []
    for i in range(num_segments):
        if smoothed[i] >= DANGER_THRESHOLD and not in_danger:
            zone_start = i
            in_danger = True
        elif (smoothed[i] < DANGER_THRESHOLD or i == num_segments - 1) and in_danger:
            zone_end = i
            zone_peak = max(smoothed[zone_start:zone_end + 1])
            peak_idx = zone_start + smoothed[zone_start:zone_end + 1].index(zone_peak)
            danger_zones.append({
                "start_s": zone_start * seg_dur,
                "end_s": (zone_end + 1) * seg_dur,
                "peak_s": peak_idx * seg_dur,
                "peak_val": zone_peak / max_smooth,
                "duration": (zone_end - zone_start + 1) * seg_dur
            })
            in_danger = False

    # ===== STATS =====
    total_danger_time = sum(z["duration"] for z in danger_zones)
    danger_pct = (total_danger_time / total_sec) * 100 if total_sec > 0 else 0
    safe_pct = 100 - danger_pct
    peak_zone = max(danger_zones, key=lambda z: z["peak_val"]) if danger_zones else None
    max_single_danger = max(events_scored, key=lambda e: e["danger"]) if events_scored else None

    # ===== HTML: DENSITY AREA CHART =====
    # Build SVG path for smooth area chart
    svg_w = 800
    svg_h = 100
    points = []
    for i in range(num_segments):
        x = (i / num_segments) * svg_w
        y = svg_h - (smoothed[i] / max_smooth) * (svg_h - 5)
        points.append(f"{x:.1f},{y:.1f}")

    path_line = "M " + " L ".join(points)
    path_area = path_line + f" L {svg_w},{svg_h} L 0,{svg_h} Z"

    # Gradient stops
    gradient_stops = ""
    for i in range(num_segments):
        offset = (i / num_segments) * 100
        norm = smoothed[i] / max_smooth
        if norm >= 0.7:
            color = "#ef4444"
        elif norm >= 0.4:
            color = "#f59e0b"
        elif norm >= 0.15:
            color = "#3b82f6"
        else:
            color = "#1e3a5f"
        gradient_stops += f'<stop offset="{offset:.0f}%" stop-color="{color}" stop-opacity="0.7"/>'

    # Danger zone highlights
    zone_rects = ""
    for z in danger_zones:
        zx = (z["start_s"] / total_sec) * svg_w
        zw = (z["duration"] / total_sec) * svg_w
        zone_rects += f'<rect x="{zx:.0f}" y="0" width="{zw:.0f}" height="{svg_h}" fill="#ef4444" fill-opacity="0.08" rx="3"/>'

    # Peak markers
    peak_markers = ""
    for z in danger_zones:
        px = (z["peak_s"] / total_sec) * svg_w
        py = svg_h - z["peak_val"] * (svg_h - 5)
        peak_markers += f'''
        <circle cx="{px:.0f}" cy="{py:.0f}" r="4" fill="#ef4444" stroke="#fff" stroke-width="1.5">
            <animate attributeName="r" values="4;6;4" dur="2s" repeatCount="indefinite"/>
        </circle>'''

    # ===== DANGER ZONE CARDS =====
    zone_cards = ""
    for zi, z in enumerate(sorted(danger_zones, key=lambda x: x["peak_val"], reverse=True)[:3]):
        rank_icon = ["🥇", "🥈", "🥉"][zi] if zi < 3 else "📍"
        bar_w = z["peak_val"] * 100
        bar_color = "#ef4444" if z["peak_val"] >= 0.7 else ("#f59e0b" if z["peak_val"] >= 0.4 else "#3b82f6")
        zone_cards += f"""
        <div class="zone-card">
            <div class="zone-rank">{rank_icon}</div>
            <div class="zone-info">
                <div class="zone-time">{z['start_s']:.0f}s → {z['end_s']:.0f}s <span class="zone-dur">({z['duration']:.1f}s)</span></div>
                <div class="zone-bar-bg"><div class="zone-bar-fill" style="width:{bar_w:.0f}%;background:{bar_color};"></div></div>
            </div>
            <div class="zone-pct" style="color:{bar_color};">{z['peak_val']*100:.0f}%</div>
        </div>"""

    # ===== FACTOR BREAKDOWN =====
    factor_html = ""
    if max_single_danger:
        ev = max_single_danger
        factor_html = f"""
        <div class="factor-section">
            <div class="factor-title">🔬 Phân Tích Yếu Tố Nguy Hiểm Cao Nhất</div>
            <div class="factor-grid">
                <div class="factor-item">
                    <div class="factor-icon">💪</div>
                    <div class="factor-label">Cường độ lực</div>
                    <div class="factor-val" style="color:{'#ef4444' if ev['f_score']>=3 else '#f59e0b'}">{ev['force']}</div>
                    <div class="factor-score">×{ev['f_score']:.1f}</div>
                </div>
                <div class="factor-item">
                    <div class="factor-icon">🔪</div>
                    <div class="factor-label">Vũ khí / Công cụ</div>
                    <div class="factor-val" style="color:{'#ef4444' if ev['w_score']>=2 else '#10b981'}">{ev['weapon'].title()}</div>
                    <div class="factor-score">×{ev['w_score']:.1f}</div>
                </div>
                <div class="factor-item">
                    <div class="factor-icon">🎯</div>
                    <div class="factor-label">Vùng va chạm</div>
                    <div class="factor-val" style="color:{'#ef4444' if ev['c_score']>=2 else '#10b981'}">{ev['contact'].title()}</div>
                    <div class="factor-score">×{ev['c_score']:.1f}</div>
                </div>
                <div class="factor-item">
                    <div class="factor-icon">⚡</div>
                    <div class="factor-label">Tổng hợp</div>
                    <div class="factor-val" style="color:#ef4444;font-size:18px;">{ev['danger']:.1f}</div>
                    <div class="factor-score">điểm</div>
                </div>
            </div>
        </div>"""

    return f"""
    <div id="density-root" style="background:linear-gradient(135deg,#080c14,#0f172a);border:1px solid #1e293b;border-radius:12px;padding:16px;font-family:'Segoe UI',system-ui,sans-serif;">

    <style>
        #density-root * {{ box-sizing:border-box; }}

        .den-header {{ display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:14px; }}
        .den-title {{ color:#e2e8f0; font-size:14px; font-weight:800; }}
        .den-subtitle {{ color:#64748b; font-size:10px; margin-top:2px; }}

        .den-stats {{ display:flex; gap:12px; }}
        .den-stat-box {{
            background:#111827; border:1px solid #1e293b; border-radius:8px;
            padding:8px 14px; text-align:center; min-width:80px;
        }}
        .den-stat-val {{ font-size:18px; font-weight:800; }}
        .den-stat-lbl {{ font-size:8px; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; margin-top:2px; }}

        .den-chart {{ background:#0f172a; border-radius:8px; padding:8px; margin-bottom:12px; position:relative; }}
        .den-chart svg {{ width:100%; height:auto; }}

        .den-y-labels {{ position:absolute; left:4px; top:8px; bottom:24px; display:flex; flex-direction:column; justify-content:space-between; }}
        .den-y-label {{ font-size:8px; color:#475569; }}

        .den-time-axis {{ display:flex; justify-content:space-between; padding:0 8px; }}
        .den-time-label {{ font-size:8px; color:#64748b; }}

        .zones-title {{ color:#94a3b8; font-size:11px; font-weight:700; margin-bottom:6px; }}
        .zone-card {{
            display:flex; align-items:center; gap:10px; padding:6px 10px;
            background:#111827; border:1px solid #1e293b; border-radius:6px; margin-bottom:4px;
        }}
        .zone-rank {{ font-size:16px; }}
        .zone-info {{ flex:1; }}
        .zone-time {{ font-size:11px; color:#e2e8f0; font-weight:600; }}
        .zone-dur {{ color:#64748b; font-size:10px; }}
        .zone-bar-bg {{ height:4px; background:#1e293b; border-radius:2px; margin-top:3px; }}
        .zone-bar-fill {{ height:100%; border-radius:2px; transition:width 1s ease; }}
        .zone-pct {{ font-size:14px; font-weight:800; min-width:40px; text-align:right; }}

        .donut-section {{ display:flex; align-items:center; gap:20px; margin-top:12px; padding:10px; background:#111827; border-radius:8px; border:1px solid #1e293b; }}
        .donut-labels {{ flex:1; }}
        .donut-row {{ display:flex; justify-content:space-between; align-items:center; padding:3px 0; font-size:11px; }}
        .donut-label {{ color:#94a3b8; }}
        .donut-val {{ font-weight:700; }}

        .factor-section {{ margin-top:12px; padding:10px; background:#111827; border-radius:8px; border:1px solid #1e293b; }}
        .factor-title {{ color:#94a3b8; font-size:11px; font-weight:700; margin-bottom:8px; }}
        .factor-grid {{ display:flex; gap:8px; }}
        .factor-item {{ flex:1; text-align:center; padding:6px; background:#0f172a; border-radius:6px; }}
        .factor-icon {{ font-size:18px; margin-bottom:2px; }}
        .factor-label {{ font-size:8px; color:#64748b; text-transform:uppercase; }}
        .factor-val {{ font-size:11px; color:#e2e8f0; font-weight:700; margin:2px 0; }}
        .factor-score {{ font-size:10px; color:#64748b; }}

        .phase-bar {{ display:flex; height:6px; border-radius:3px; overflow:hidden; margin-top:6px; }}
        .phase-seg {{ transition:width 1s ease; }}
    </style>

    <!-- HEADER -->
    <div class="den-header">
        <div>
            <div class="den-title">🔥 PHÂN TÍCH MẬT ĐỘ BẠO LỰC ĐA CHIỀU</div>
            <div class="den-subtitle">Trọng số: Lực × Vũ khí × Vùng va chạm × Số nạn nhân</div>
        </div>
        <div class="den-stats">
            <div class="den-stat-box">
                <div class="den-stat-val" style="color:#ef4444;">{danger_pct:.0f}%</div>
                <div class="den-stat-lbl">Thời gian nguy hiểm</div>
            </div>
            <div class="den-stat-box">
                <div class="den-stat-val" style="color:#10b981;">{safe_pct:.0f}%</div>
                <div class="den-stat-lbl">Thời gian an toàn</div>
            </div>
            <div class="den-stat-box">
                <div class="den-stat-val" style="color:#f59e0b;">{len(danger_zones)}</div>
                <div class="den-stat-lbl">Vùng nguy hiểm</div>
            </div>
        </div>
    </div>

    <!-- SVG AREA CHART -->
    <div class="den-chart">
        <svg viewBox="0 0 {svg_w} {svg_h + 5}" preserveAspectRatio="none">
            <defs>
                <linearGradient id="areaGrad" x1="0%" y1="0%" x2="100%" y2="0%">{gradient_stops}</linearGradient>
                <linearGradient id="lineGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stop-color="#ef4444"/>
                    <stop offset="50%" stop-color="#f59e0b"/>
                    <stop offset="100%" stop-color="#ef4444"/>
                </linearGradient>
            </defs>
            <!-- Grid lines -->
            <line x1="0" y1="{svg_h*0.25}" x2="{svg_w}" y2="{svg_h*0.25}" stroke="#1e293b" stroke-width="0.5" stroke-dasharray="4"/>
            <line x1="0" y1="{svg_h*0.5}" x2="{svg_w}" y2="{svg_h*0.5}" stroke="#1e293b" stroke-width="0.5" stroke-dasharray="4"/>
            <line x1="0" y1="{svg_h*0.75}" x2="{svg_w}" y2="{svg_h*0.75}" stroke="#1e293b" stroke-width="0.5" stroke-dasharray="4"/>
            <!-- Danger zones -->
            {zone_rects}
            <!-- Area fill -->
            <path d="{path_area}" fill="url(#areaGrad)" opacity="0.6"/>
            <!-- Line -->
            <path d="{path_line}" fill="none" stroke="url(#lineGrad)" stroke-width="2" stroke-linejoin="round"/>
            <!-- Peak markers -->
            {peak_markers}
        </svg>
        <div class="den-time-axis">
            <div class="den-time-label">00:00</div>
            <div class="den-time-label">{int(total_sec*0.25)//60:02d}:{int(total_sec*0.25)%60:02d}</div>
            <div class="den-time-label">{int(total_sec*0.5)//60:02d}:{int(total_sec*0.5)%60:02d}</div>
            <div class="den-time-label">{int(total_sec*0.75)//60:02d}:{int(total_sec*0.75)%60:02d}</div>
            <div class="den-time-label">{int(total_sec)//60:02d}:{int(total_sec)%60:02d}</div>
        </div>
    </div>

    <!-- TOP DANGER ZONES -->
    <div class="zones-title">🎯 TOP VÙNG NGUY HIỂM NHẤT</div>
    {zone_cards if zone_cards else '<div style="color:#64748b;font-size:11px;padding:8px;">Không phát hiện vùng nguy hiểm.</div>'}

    <!-- DANGER / SAFE RATIO BAR -->
    <div class="donut-section">
        <div style="flex:1;">
            <div style="color:#94a3b8;font-size:10px;font-weight:700;margin-bottom:6px;">TỶ LỆ NGUY HIỂM / AN TOÀN</div>
            <div class="phase-bar">
                <div class="phase-seg" style="width:{danger_pct:.0f}%;background:linear-gradient(90deg,#ef4444,#dc2626);"></div>
                <div class="phase-seg" style="width:{safe_pct:.0f}%;background:linear-gradient(90deg,#10b981,#059669);"></div>
            </div>
            <div style="display:flex;justify-content:space-between;margin-top:4px;">
                <div class="donut-row"><span class="donut-label">🔴 Nguy hiểm</span><span class="donut-val" style="color:#ef4444;">{danger_pct:.1f}% ({total_danger_time:.1f}s)</span></div>
                <div class="donut-row"><span class="donut-label">🟢 An toàn</span><span class="donut-val" style="color:#10b981;">{safe_pct:.1f}% ({total_sec - total_danger_time:.1f}s)</span></div>
            </div>
        </div>
    </div>

    <!-- FACTOR BREAKDOWN -->
    {factor_html}

    </div>
    """
def check_needs_correction(result_dict):
    """Kiểm tra kết quả VLM có cần sửa lỗi không. Trả về (cần_sửa, danh_sách_vấn_đề)."""
    issues = []
    ext = result_dict.get("extracted_data", {})
    main_cat = ext.get("main_category", "")
    danger = ext.get("danger_severity_score", 0)
    confidence = result_dict.get("confidence_score", 1.0)
    timeline = ext.get("timeline_events", [])
    audit = result_dict.get("consistency_audit", {})

    VIOLENT_CATS = ["Punching", "Kicking", "Slapping", "Pushing/Shoving", "Hair pulling",
                    "Wrestling down / Throwing to the ground", "Group fighting / Mob beating",
                    "Threatening with a dangerous weapon"]
    NORMAL_CATS = ["Walking", "Jogging / Running", "Standing still", "Sitting",
                   "Playing sports", "Handshaking", "Peaceful gathering", "Dancing"]

    # 1. Confidence thấp
    if confidence < 0.65:
        issues.append(f"⚠️ Độ tin cậy thấp: {confidence:.0%} (ngưỡng ≥ 65%)")

    # 2. Mâu thuẫn từ consistency_audit
    if audit.get("has_logical_contradiction", False):
        explanation = audit.get("conflict_explanation", "Không rõ")
        issues.append(f"🔴 Tự phát hiện mâu thuẫn: {explanation}")

    # 3. Nhãn bạo lực nhưng danger thấp
    if main_cat in VIOLENT_CATS and danger <= 3:
        issues.append(f"🔴 Nhãn '{main_cat}' (bạo lực) nhưng danger_score={danger}/10 (quá thấp, phải ≥5)")

    # 4. Nhãn bình thường nhưng danger cao
    if main_cat in NORMAL_CATS and danger >= 6:
        issues.append(f"🔴 Nhãn '{main_cat}' (bình thường) nhưng danger_score={danger}/10 (quá cao, phải ≤2)")

    # 5. Không có timeline events
    if not timeline:
        issues.append("⚠️ Không có timeline_events (thiếu dữ liệu sự kiện)")

    # 6. Timeline có hành động mâu thuẫn với nhãn chính
    if timeline:
        action_labels = [ev.get("action_label", "") for ev in timeline]
        violent_actions = [a for a in action_labels if any(v.lower() in a.lower() for v in ["Punch", "Kick", "Slap", "Push", "Pull", "Wrestl", "Fight", "Threaten"])]
        normal_actions = [a for a in action_labels if any(n.lower() in a.lower() for n in ["Walk", "Sit", "Stand", "Jog", "Run", "Sport", "Handshak", "Danc", "Peaceful"])]

        if main_cat in VIOLENT_CATS and len(normal_actions) > len(violent_actions) and len(normal_actions) >= 2:
            issues.append(f"⚠️ Nhãn chính là bạo lực nhưng đa số sự kiện lại bình thường ({len(normal_actions)}/{len(timeline)})")

        if main_cat in NORMAL_CATS and len(violent_actions) > len(normal_actions) and len(violent_actions) >= 2:
            issues.append(f"⚠️ Nhãn chính là bình thường nhưng đa số sự kiện lại bạo lực ({len(violent_actions)}/{len(timeline)})")

    # 7. Danger score = 0 nhưng có sự kiện force "Mạnh"
    if danger <= 1 and timeline:
        strong_forces = [ev for ev in timeline if "Mạnh" in (ev.get("force_intensity") or "") or "Nguy hiểm" in (ev.get("force_intensity") or "")]
        if strong_forces:
            issues.append(f"🔴 danger_score={danger} nhưng có {len(strong_forces)} sự kiện lực 'Mạnh/Nguy hiểm'")

    return len(issues) > 0, issues


def run_self_correction(frame_parts, initial_result, issues, status_container=None):
    """Chạy VLM lần 2 với context sửa lỗi. Trả về kết quả đã sửa hoặc None."""
    issues_text = "\n".join(f"  {i+1}. {iss}" for i, iss in enumerate(issues))

    correction_prompt = f"""
BẠN LÀ: Chuyên gia Kiểm Định & Sửa Lỗi Phân Tích Video (EduViolence AI - Self-Correction Module).

KẾT QUẢ PHÂN TÍCH LẦN 1 (có thể chứa lỗi):
{json.dumps(initial_result, ensure_ascii=False, indent=2)[:3000]}

CÁC VẤN ĐỀ PHÁT HIỆN:
{issues_text}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
NHIỆM VỤ SỬA LỖI:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. XEM LẠI CÁC KHUNG HÌNH VIDEO MỘT LẦN NỮA, tập trung vào các vấn đề đã phát hiện.

2. VỚI MỖI VẤN ĐỀ, xác định:
   - Kết quả lần 1 ĐÚNG hay SAI?
   - Nếu SAI → sửa thành gì? Giải thích lý do.

3. QUY TẮC SỬA:
   - Nếu nhãn bạo lực nhưng danger thấp → hoặc SỬA nhãn thành bình thường, hoặc TĂNG danger score.
   - Nếu nhãn bình thường nhưng danger cao → hoặc SỬA nhãn thành bạo lực, hoặc GIẢM danger score.
   - Nếu timeline mâu thuẫn với nhãn chính → điều chỉnh nhãn chính theo đa số sự kiện.
   - NẾU KHÔNG CHẮC CHẮN → ưu tiên phân loại an toàn hơn (bình thường).

4. TRẢ VỀ KẾT QUẢ ĐÃ SỬA với cùng schema JSON, đảm bảo:
   - main_category khớp với danger_severity_score
   - timeline_events nhất quán với main_category
   - confidence_score phản ánh độ chắc chắn SAU KHI SỬA
   - Toàn bộ mô tả BẰNG TIẾNG VIỆT CÓ DẤU 100%

5. Thêm trường "correction_notes" mô tả những gì đã sửa.
"""

    if status_container:
        status_container.write("🔄 **Self-Correction:** Đang phân tích lại với context sửa lỗi...")

    response, used_model = call_vlm_with_smart_retry(
        contents=frame_parts + [correction_prompt],
        use_schema=True,
        status_container=status_container
    )

    if response:
        try:
            corrected = json.loads(response.text)
            if status_container:
                status_container.write(f"✅ Self-Correction hoàn tất! (Model: {used_model})")
            return corrected, used_model
        except Exception:
            pass

    if status_container:
        status_container.write("⚠️ Self-Correction thất bại, giữ kết quả lần 1.")
    return None, None

# ===== DYNAMIC TASK UNDERSTANDING =====
TASK_TYPES = {
    "🎯 Phân loại hành vi (16 nhãn)": {
        "id": "classify",
        "description": "Phân loại video vào 1 trong 16 nhãn hành vi chuẩn",
        "use_schema": True,
    },
    "🔢 Đếm & Nhận diện đối tượng": {
        "id": "count",
        "description": "Đếm số người, vật thể, xác định vị trí và đặc điểm",
        "use_schema": False,
    },
    "📝 Tóm tắt nội dung video": {
        "id": "summarize",
        "description": "Tóm tắt diễn biến video từ đầu đến cuối",
        "use_schema": False,
    },
    "⚠️ Đánh giá mức độ nguy hiểm": {
        "id": "danger",
        "description": "Phân tích chi tiết mức độ nguy hiểm, vùng va chạm, lực tác động",
        "use_schema": False,
    },
        "🔊 Phân tích âm thanh (Audio)": {
        "id": "audio",
        "description": "Phân tích tiếng la hét, va chạm, giọng nói trong video",
        "use_schema": False,
    },
    "🔍 Phân tích tùy chỉnh (tự đặt câu hỏi)": {
        "id": "custom",
        "description": "Tự nhập câu hỏi bất kỳ về video",
        "use_schema": False,
    },
}

def build_dynamic_prompt(task_id, custom_question="", num_frames=12):
    """Tạo prompt phù hợp với từng loại nhiệm vụ."""

    base_context = f"""Bạn là Chuyên gia Phân tích Video Học đường (EduViolence AI).
DỮ LIỆU: {num_frames} khung hình trích xuất đều từ video, gắn nhãn thời gian.
Toàn bộ câu trả lời PHẢI BẰNG TIẾNG VIỆT CÓ DẤU 100%.\n\n"""

    if task_id == "classify":
        return base_context + """
━━━ NHIỆM VỤ: PHÂN LOẠI HÀNH VI (16 NHÃN) ━━━

BƯỚC 1 - QUAN SÁT THỊ GIÁC (visual_evidence):
Mô tả CHI TIẾT: số người, tư thế, tay chân, khoảng cách, bối cảnh, vật thể đặc biệt, biểu cảm.

BƯỚC 2 - PHÂN TÍCH CHUYỂN ĐỘNG XUYÊN THỜI GIAN (action_classification_reasoning):
So sánh thay đổi giữa các frame: di chuyển, va chạm, tư thế đột ngột, chu kỳ hay đột ngột.

BƯỚC 3 - PHÂN LOẠI vào ĐÚNG 1/16 NHÃN:
[Bạo lực ≥5]: Punching, Kicking, Slapping, Pushing/Shoving, Hair pulling, Wrestling down / Throwing to the ground, Group fighting / Mob beating, Threatening with a dangerous weapon.
[Bình thường ≤2]: Walking, Jogging / Running, Standing still, Sitting, Playing sports, Handshaking, Peaceful gathering, Dancing.

QUY TẮC: Playing sports CÓ BÓNG/DỤNG CỤ. 1 người = không bạo lực. Không chắc → ưu tiên bình thường.

BƯỚC 4 - CHUỖI SỰ KIỆN: event_id, start_time, end_time, action_label, actor_id, target_id, body_part_or_weapon, target_contact_point, force_intensity, physical_impact, causal_leads_to.

BƯỚC 5 - TỰ KIỂM CHỨNG: Nhãn khớp bằng chứng? danger_score hợp lý? Ghi vào consistency_audit.
"""

    elif task_id == "count":
        return base_context + """
━━━ NHIỆM VỤ: ĐẾM & NHẬN DIỆN ĐỐI TƯỢNG ━━━

Hãy phân tích video và trả lời bằng Tiếng Việt theo format:

## 👥 NGƯỜI (People Detection)
Với MỖI người nhìn thấy, mô tả:
- **ID**: Person_01, Person_02...
- **Giới tính ước đoán**: Nam / Nữ / Không xác định
- **Trang phục**: Mô tả chi tiết quần áo, màu sắc
- **Tư thế**: Đứng / Ngồi / Nằm / Di chuyển
- **Vị trí trong khung hình**: Trái / Giữa / Phải, Gần camera / Xa
- **Hành động**: Đang làm gì
- **Xuất hiện từ frame nào đến frame nào**

### Tổng kết:
| Thống kê | Số lượng |
|----------|---------|
| Tổng số người | ? |
| Nam | ? |
| Nữ | ? |
| Đang di chuyển | ? |
| Đang đứng/ngồi yên | ? |

## 🏷️ VẬT THỂ ĐÁNG CHÚ Ý (Objects)
Liệt kê các vật thể quan trọng: bàn ghế, bóng, gậy, dao, cặp sách, xe, bảng...
- Tên vật thể — Vị trí — Có liên quan đến hành vi không?

## 📍 BỐI CẢNH (Scene Context)
- Địa điểm: Trong nhà / Ngoài trời / Sân trường / Hành lang...
- Thời gian: Ban ngày / Ban đêm
- Camera: Góc quay cố định / Di động
"""

    elif task_id == "summarize":
        return base_context + """
━━━ NHIỆM VỤ: TÓM TẮT NỘI DUNG VIDEO ━━━

Hãy tóm tắt video bằng Tiếng Việt theo cấu trúc:

## 📋 TÓM TẮT TỔNG QUAN
Mô tả ngắn gọn (2-3 câu) về nội dung chính của video.

## 📍 BỐI CẢNH
- **Địa điểm:** Mô tả không gian
- **Thời gian:** Ban ngày/đêm, ước lượng thời điểm
- **Số người tham gia:** Bao nhiêu người

## ⏱️ DIỄN BIẾN THEO THỜI GIAN
Mô tả CHI TIẾT từng giai đoạn:

### Giai đoạn 1: Mở đầu (00:00 - ?)
- Mô tả chi tiết xảy ra gì...

### Giai đoạn 2: Phát triển (? - ?)
- Mô tả chi tiết...

### Giai đoạn 3: Kết thúc (? - cuối)
- Mô tả chi tiết...

## 🎭 NHÂN VẬT CHÍNH
Với mỗi người quan trọng:
- Vai trò (chủ thể / nạn nhân / người can ngăn / người qua đường)
- Hành động nổi bật
- Cảm xúc/thái độ quan sát được

## ⚡ ĐÁNH GIÁ NHANH
- **Loại sự kiện:** Bạo lực / Bình thường / Đáng ngờ
- **Mức nguy hiểm:** Thấp / Trung bình / Cao / Rất cao
- **Cần can thiệp không?:** Có / Không — Lý do
"""

    elif task_id == "danger":
        return base_context + """
━━━ NHIỆM VỤ: ĐÁNH GIÁ MỨC ĐỘ NGUY HIỂM CHI TIẾT ━━━

Hãy phân tích mức độ nguy hiểm bằng Tiếng Việt:

## 🚨 ĐÁNH GIÁ TỔNG QUAN
- **Mức nguy hiểm:** ?/10
- **Phân loại:** An toàn / Cảnh báo / Nguy hiểm / Khẩn cấp
- **Cần can thiệp?:** Có / Không

## 💪 PHÂN TÍCH LỰC TÁC ĐỘNG
Với MỖI hành vi va chạm:
| # | Thời điểm | Hành động | Vũ khí/Bộ phận | Vùng bị tác động | Cường độ | Hệ quả vật lý |
|---|-----------|-----------|---------------|------------------|---------|---------------|
| 1 | 00:00-00:03 | ? | ? | ? | Nhẹ/TB/Mạnh | ? |

## 🎯 PHÂN TÍCH VÙNG CƠ THỂ BỊ TÁC ĐỘNG
- **Vùng đầu/mặt** (nguy hiểm cao): Có/Không — Chi tiết
- **Vùng cổ** (nguy hiểm rất cao): Có/Không — Chi tiết
- **Vùng ngực/bụng** (nguy hiểm trung bình): Có/Không — Chi tiết
- **Vùng lưng/vai** (nguy hiểm thấp-TB): Có/Không — Chi tiết
- **Vùng chân** (nguy hiểm thấp): Có/Không — Chi tiết

## 🔪 PHÂN TÍCH VŨ KHÍ/CÔNG CỤ
- Có sử dụng vũ khí/hung khí không?
- Loại: Tay không / Gậy / Dao / Ghế / Chai / Khác
- Mức độ sát thương tiềm tàng: Thấp / Trung bình / Cao

## 📈 ĐƯỜNG CONG LEO THANG
Đánh giá diễn biến nguy hiểm theo thời gian:
- Giai đoạn khởi phát → Giai đoạn leo thang → Đỉnh điểm → Hạ nhiệt?
- Có xu hướng tăng hay giảm?

## 🏥 KHUYẾN NGHỊ
- Mức độ ưu tiên can thiệp: Thấp / Trung bình / Cao / Khẩn cấp
- Hành động đề xuất: Theo dõi / Cảnh báo / Can thiệp / Gọi hỗ trợ
"""

    elif task_id == "custom":
        return base_context + f"""
━━━ NHIỆM VỤ TÙY CHỈNH ━━━

Người dùng yêu cầu: "{custom_question}"

Hãy phân tích video và trả lời câu hỏi trên một cách CHI TIẾT, CÓ CẤU TRÚC bằng Tiếng Việt.
Sử dụng markdown headers (##, ###), bảng, danh sách để trình bày rõ ràng.
Trích dẫn mốc thời gian cụ thể từ các khung hình khi trả lời.
"""

    return base_context + "Phân tích video chi tiết bằng Tiếng Việt."
st.title("🛡️ Agentic VLM Hub (EduViolence AI)")
st.sidebar.header("🔑 Cấu Hình Hệ Thống")
st.sidebar.info(f"🧠 **VLM Engine:** `{FIXED_VLM_MODEL}` (Suy Luận CoT Đa Chiều)")
st.sidebar.markdown("---")
selected_dataset_name = st.sidebar.selectbox("📂 Chọn CSDL 16 Hành Vi:", list(DATASET_CONFIGS.keys()))
cfg = DATASET_CONFIGS[selected_dataset_name]

json_file = cfg["json"]
data = []
if os.path.exists(json_file):
    try:
        with open(json_file, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = []

k1, k2, k3, k4 = st.columns(4)
k1.metric("Video trong CSDL", f"{len(data)} video")
k2.metric("Nút Đồ Thị Tri Thức", f"{kg_rag_engine.get_graph_summary()['total_nodes']} nodes")
k3.metric("Quan Hệ (Graph Edges)", f"{kg_rag_engine.get_graph_summary()['total_edges']} edges")
k4.metric("Bể Khóa Dự Phòng", f"{key_pool.total_keys()} API Keys")

st.divider()

tab_upload, tab_player, tab_graph_rag, tab_data = st.tabs([
    "📤 Phân Tích Video (VLM Live)",
    "🎥 Video Player & Chẩn Đoán",
    "🤖 Đồ Thị Tri Thức & Co-Pilot",
    "📁 Xuất Báo Cáo CSV (18 Cột)"
])

# TAB 1: LIVE UPLOAD + DYNAMIC TASK
with tab_upload:
    st.subheader("🧠 Phân Tích Hành Vi Video Bằng VLM (Suy Luận CoT Đa Chiều)")
    up_col1, up_col2 = st.columns([1.1, 1.3])
    
    with up_col1:
        uploaded_file = st.file_uploader("Chọn file video MP4:", type=["mp4"])
        if uploaded_file:
            st.video(uploaded_file)

            st.markdown("---")
            selected_task = st.selectbox(
                "🧠 Chọn chế độ phân tích:",
                list(TASK_TYPES.keys()),
                index=0
            )
            task_info = TASK_TYPES[selected_task]
            st.caption(f"📋 {task_info['description']}")
            analysis_speed = st.radio(
                "⚡ Tốc độ phân tích:",
                ["⚡ Nhanh (Montage 1 ảnh)", "🔬 Chi tiết (Multi-frame)"],
                index=0,
                horizontal=True
            )
            use_montage = "Nhanh" in analysis_speed

            custom_question = ""
            if task_info["id"] == "custom":
                custom_question = st.text_area(
                    "✏️ Nhập câu hỏi của bạn về video:",
                    placeholder="Ví dụ: Có bao nhiêu người mặc áo trắng? Ai là người tấn công trước?",
                    height=80
                )

            analyze_btn = st.button("🚀 Chạy Phân Tích", type="primary", use_container_width=True)

            if st.button("✂️ Cắt Clips Chuẩn (2.0s) & Tải ZIP", use_container_width=True):
                with st.spinner("Đang cắt clips 2.0s..."):
                    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as tmp_up:
                        tmp_up.write(uploaded_file.getvalue())
                        tmp_up_path = tmp_up.name
                    zip_data = generate_standard_clips_zip(tmp_up_path, clip_duration=2.0, stride=1.0)
                    os.remove(tmp_up_path)
                    if zip_data:
                        st.download_button(
                            label=f"📥 Tải Bộ Clips Chuẩn ({uploaded_file.name}.zip)",
                            data=zip_data,
                            file_name=f"{os.path.splitext(uploaded_file.name)[0]}_Scientific_Clips.zip",
                            mime="application/zip"
                        )
        else:
            analyze_btn = False

    with up_col2:
        if uploaded_file and analyze_btn:
            tmp_path = None
            try:
                with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as tmp:
                    tmp.write(uploaded_file.getvalue())
                    tmp_path = tmp.name

                if use_montage:
                    frame_parts, vid_duration = extract_montage_grid(tmp_path, num_samples=6)
                    if not frame_parts:
                        st.error("❌ Không thể trích xuất montage từ video.")
                        st.stop()
                    adaptive_frames = 6
                else:
                    adaptive_frames, vid_duration = get_adaptive_num_frames(tmp_path)
                    frame_parts = extract_uniform_keyframes(tmp_path, num_frames=adaptive_frames)

                prompt_dynamic = build_dynamic_prompt(
                    task_info["id"], custom_question, adaptive_frames
                )

                with st.status(f"🧠 Đang phân tích: {selected_task}...", expanded=True) as status_vlm:
                    contents_payload = frame_parts + [prompt_dynamic]
                    response, used_model = call_vlm_with_smart_retry(
                        contents=contents_payload,
                        use_schema=task_info["use_schema"],
                        status_container=status_vlm
                    )

                    if response is None:
                        status_vlm.update(label="❌ Thất bại!", state="error", expanded=True)
                        st.error(f"❌ Không thể phân tích sau {MAX_VLM_RETRIES} lần thử.")
                        st.stop()

                    status_vlm.update(label=f"✅ Hoàn tất! ({used_model})", state="complete", expanded=False)

                # ===== XỬ LÝ KẾT QUẢ THEO TASK TYPE =====
                if task_info["id"] == "classify":
                    result_dict = json.loads(response.text)

                    # Self-Correction Loop
                    needs_fix, issues = check_needs_correction(result_dict)
                    correction_applied = False
                    if needs_fix:
                        with st.status("🔄 Self-Correction: Phát hiện vấn đề...", expanded=True) as status_fix:
                            for iss in issues:
                                status_fix.write(iss)
                            corrected_result, corr_model = run_self_correction(
                                frame_parts, result_dict, issues, status_fix
                            )
                            if corrected_result:
                                result_dict = corrected_result
                                correction_applied = True
                                status_fix.update(label="✅ Self-Correction hoàn tất!", state="complete")
                            else:
                                status_fix.update(label="⚠️ Giữ kết quả lần 1", state="complete")

                                        # Bổ sung audio evidence
                    audio_evidence = None
                    try:
                        audio_bytes = extract_audio_from_video(tmp_path)
                        if audio_bytes:
                            with st.status("🔊 Thu thập audio evidence...", expanded=False) as status_aud:
                                audio_evidence = analyze_audio_with_vlm(audio_bytes, status_aud)
                                status_aud.update(label="✅ Audio evidence!", state="complete")
                    except Exception:
                        pass

                    ext = result_dict.get("extracted_data", {})
                    main_act = ext.get("main_category", "Walking")
                    auto_target_cat = CATEGORY_MAPPING_16.get(main_act, selected_dataset_name)

                    st.session_state["last_analyzed_result"] = {
                        "file_name": uploaded_file.name,
                        "tier2_model_used": used_model or FIXED_VLM_MODEL,
                        "dataset_category": auto_target_cat,
                        "analysis": result_dict,
                        "audio_evidence": audio_evidence
                    }
                    st.session_state["last_correction_applied"] = correction_applied
                    st.session_state["last_task_type"] = "classify"
                    st.session_state.pop("last_free_result", None)

                elif task_info["id"] == "audio":
                    with st.status("🔊 Đang trích xuất & phân tích audio...", expanded=True) as status_audio:
                        audio_bytes = extract_audio_from_video(tmp_path)
                        if audio_bytes:
                            status_audio.write(f"✅ Trích xuất audio: {len(audio_bytes)//1024} KB")
                            audio_result = analyze_audio_with_vlm(audio_bytes, status_audio)
                            if audio_result:
                                st.session_state["last_free_result"] = audio_result
                                st.session_state["last_task_type"] = "audio"
                                st.session_state["last_task_label"] = selected_task
                                st.session_state.pop("last_analyzed_result", None)
                                status_audio.update(label="✅ Audio Analysis hoàn tất!", state="complete")
                            else:
                                st.error("❌ Không thể phân tích audio.")
                                status_audio.update(label="❌ Thất bại", state="error")
                        else:
                            st.warning("⚠️ Video không có audio hoặc chưa cài ffmpeg.\n\nCài ffmpeg: `choco install ffmpeg`")
                            status_audio.update(label="⚠️ Không có audio", state="error")

                else:
                    st.session_state["last_free_result"] = response.text
                    st.session_state["last_task_type"] = task_info["id"]
                    st.session_state["last_task_label"] = selected_task
                    st.session_state.pop("last_analyzed_result", None)

            except Exception as e_live:
                st.error(f"❌ Lỗi xử lý: {e_live}")
            finally:
                if tmp_path and os.path.exists(tmp_path):
                    os.remove(tmp_path)

        # ===== HIỂN THỊ KẾT QUẢ TASK TỰ DO (count, summarize, danger, custom) =====
        if st.session_state.get("last_task_type") not in [None, "classify"] and "last_free_result" in st.session_state:
            st.markdown(f"### 📊 Kết Quả: {st.session_state.get('last_task_label', '')}")
            st.markdown(st.session_state["last_free_result"])

        # ===== HIỂN THỊ KẾT QUẢ CLASSIFY =====
        if "last_analyzed_result" in st.session_state and st.session_state.get("last_task_type") == "classify":
            res = st.session_state["last_analyzed_result"]
            analysis = res["analysis"]
            ext = analysis.get("extracted_data", {})
            danger_score = ext.get("danger_severity_score", 0)
            main_act = ext.get("main_category", "N/A")

            st.markdown("### 📊 Kết Quả Phân Tích VLM")

            if st.session_state.get("last_correction_applied", False):
                st.success("🔄 **Self-Correction đã áp dụng** — Kết quả đã được kiểm chứng và sửa lỗi tự động.")

            c1, c2, c3 = st.columns(3)
            c1.metric("🏷️ Nhãn Hành Vi", main_act)
            c2.metric("⚠️ Điểm An Ninh", f"{danger_score}/10")
            c3.metric("📊 Tin Cậy", f"{analysis.get('confidence_score', 1.0)*100:.0f}%")

            st.markdown("##### 🌐 Đồ Thị Nhân Quả Vi Mô (Causal Sub-Graph):")
            single_graph_html = generate_single_video_graph_html(res, height=360)
            components.html(single_graph_html, height=370)

            st.markdown("##### ⏱️ Biểu Đồ Timeline:")
            timeline_html = generate_event_timeline_html(
                ext.get("timeline_events", []),
                vid_duration if 'vid_duration' in dir() else 10.0
            )
            components.html(timeline_html, height=350)

            st.markdown("##### 🔥 Phân Tích Mật Độ Bạo Lực:")
            density_html = generate_violence_density_html(
                ext.get("timeline_events", []),
                vid_duration if 'vid_duration' in dir() else 10.0
            )
            components.html(density_html, height=520)
            if res.get("audio_evidence"):
                with st.expander("🔊 Bằng Chứng Âm Thanh (Audio Evidence)", expanded=False):
                    st.markdown(res["audio_evidence"])
            with st.expander("🔎 Chuỗi Lập Luận VLM (CoT Reasoning)", expanded=False):
                st.markdown(f"**Bằng chứng thị giác:** {analysis.get('visual_evidence', 'N/A')}")
                st.markdown(f"**Lập luận phân loại:** {analysis.get('action_classification_reasoning', 'N/A')}")
                st.markdown(f"**Giải trình Re-ID:** {analysis.get('re_id_reasoning', 'N/A')}")

            with st.expander("📋 Chi Tiết Từng Sự Kiện", expanded=False):
                for ev in ext.get("timeline_events", []):
                    force = ev.get("force_intensity") or "Trung bình"
                    force_color = "🔴" if "Mạnh" in force or "Nguy hiểm" in force else ("🟡" if "Trung bình" in force else "🟢")
                    actor = ev.get("actor_id") or "P1"
                    weapon = ev.get("body_part_or_weapon") or "Tay không"
                    contact = ev.get("target_contact_point") or "Toàn thân"
                    target = f" ➔ **`{ev.get('target_id')}`** ({contact})" if ev.get("target_id") else ""

                    st.markdown(f"**`{ev.get('start_time')} - {ev.get('end_time')}`** {force_color} **[{ev.get('action_label')}]** | Lực: **`{force}`**")
                    st.markdown(f"- 👤 `{actor}` (*{weapon}*){target}")
                    st.markdown(f"- 💥 _{ev.get('physical_impact') or ev.get('description') or ''}_")
                    if ev.get("causal_leads_to"):
                        st.markdown(f"- 🔗 _{ev.get('causal_leads_to')}_")
                    st.markdown("---")
# TAB 2: PLAYER & DIAGNOSTICS
with tab_player:
    if not data:
        st.warning("Chưa có dữ liệu trong CSDL này.")
    else:
        c_left, c_right = st.columns([1.1, 1.3])
        with c_left:
            sel_file = st.selectbox("Chọn video trong CSDL:", [d["file_name"] for d in data])
            cur_item = next(d for d in data if d["file_name"] == sel_file)
            v_path = find_actual_video_path(sel_file)
            
            if v_path and os.path.exists(v_path):
                st.video(v_path)
            else:
                st.info(f"📁 Video: `{sel_file}`")

            with st.expander("📋 Thẻ Sự Kiện Chi Tiết", expanded=False):
                for ev in cur_item.get("analysis", {}).get("extracted_data", {}).get("timeline_events", []):
                    force = ev.get("force_intensity") or "Trung bình"
                    force_color = "🔴" if "Mạnh" in force or "Nguy hiểm" in force else ("🟡" if "Trung bình" in force else "🟢")
                    actor = ev.get("actor_id") or "P1"
                    weapon = ev.get("body_part_or_weapon") or "Tay không"
                    contact = ev.get("target_contact_point") or "Toàn thân"
                    target = f" ➔ **`{ev.get('target_id')}`** (Va chạm: *{contact}*)" if ev.get("target_id") else ""

                    st.markdown(f"**`{ev.get('start_time','00:00')} - {ev.get('end_time','00:00')}`** {force_color} **[{ev.get('action_label')}]** | Lực: `{force}`")
                    st.markdown(f"- 👤 `{actor}` (Vũ khí/Bộ phận: *{weapon}*){target}")
                    st.markdown(f"- 💥 **Hệ quả:** _{ev.get('physical_impact') or ev.get('description') or ''}_")
                    if ev.get("causal_leads_to"):
                        st.caption(f"🔗 **Mạch tiếp diễn:** _{ev.get('causal_leads_to')}_")
                    st.markdown("---")

        with c_right:
            analysis = cur_item.get("analysis", {})
            ext = analysis.get("extracted_data", {})
            
            st.subheader(f"📌 {sel_file}")
            st.info(f"🏷️ **Nhãn Quyết Định:** `{ext.get('main_category', 'N/A')}`")

            st.markdown("#### 🌐 Đồ Thị Nhân Quả Vi Mô")
            single_vid_graph = generate_single_video_graph_html(cur_item, height=300)
            components.html(single_vid_graph, height=310)

            st.markdown("#### ⏱️ Timeline Sự Kiện")
            vp = find_actual_video_path(sel_file)
            _, vdur = get_adaptive_num_frames(vp) if vp else (12, 10.0)
            timeline_db_html = generate_event_timeline_html(
                ext.get("timeline_events", []),
                vdur
            )
            components.html(timeline_db_html, height=320)

            st.markdown("#### 🔥 Phân Tích Mật Độ Bạo Lực")
            density_db_html = generate_violence_density_html(
                ext.get("timeline_events", []),
                vdur
            )
            components.html(density_db_html, height=520)

            with st.expander("🔎 Chuỗi Lập Luận VLM (CoT)", expanded=False):
                st.markdown(f"**Bằng chứng thị giác:** {analysis.get('visual_evidence', 'N/A')}")
                st.markdown(f"**Lập luận phân loại:** {analysis.get('action_classification_reasoning', 'N/A')}")
                st.markdown(f"**Giải trình Re-ID:** {analysis.get('re_id_reasoning', 'N/A')}")

# TAB 3: GRAPH & COPILOT
with tab_graph_rag:
    st.subheader("🌐 Đồ Thị Tri Thức Đa Chiều (Multi-Dimensional Knowledge Graph)")
    
    g_col1, g_col2 = st.columns([1.2, 1.0])
    with g_col1:
        graph_view_mode = st.radio(
            "Chế độ hiển thị Đồ thị:",
            ["🎯 Theo Nhóm Hành Vi Đang Chọn", "🌐 Toàn Bộ Đồ Thị (Mật Độ Cao)"],
            horizontal=True
        )
    with g_col2:
        node_limit = st.slider("Số lượng nút hiển thị tối đa:", min_value=50, max_value=350, value=180, step=10)

    filter_cat = cfg["key"] if "Theo Nhóm" in graph_view_mode else "ALL"
    graph_html = generate_interactive_graph_html(
        kg_rag_engine.nodes, 
        kg_rag_engine.edges, 
        filter_category=filter_cat, 
        max_nodes=node_limit, 
        video_clusters=kg_rag_engine.video_clusters
    )
    components.html(graph_html, height=540)

    st.markdown("---")
    st.subheader("🤖 Trợ Lý Co-Pilot (Knowledge Graph & Vector RAG)")
    u_q = st.text_input("Nhập câu hỏi tra cứu thông minh:", placeholder="Ví dụ: Tìm video có dùng gậy/hung khí tấn công vào vùng đầu nạn nhân...")
    if st.button("🚀 Thực Hiện Truy Vấn", type="primary") and u_q:
        with st.spinner("Đang tra cứu đồ thị..."):
            retrieved_docs = kg_rag_engine.query_rag(u_q, top_k=5)
            prompt_rag = f"""
            Dựa trên đồ thị tri thức sự kiện đa chiều sau:
            {json.dumps(retrieved_docs, ensure_ascii=False)}

            Hãy trả lời chi tiết và chính xác câu hỏi: '{u_q}'
            YÊU CẦU: Trích dẫn rõ Tên Video, Mốc thời gian (start-end), Chủ thể ra đòn (bằng công cụ gì), Nạn nhân (va chạm ở đâu), Mức độ lực và Diễn biến nhân quả tiếp theo.
            """
            response_rag, _ = call_vlm_with_smart_retry(
                contents=[prompt_rag],
                use_schema=False,
                status_container=None
            )
            if response_rag:
                st.markdown(response_rag.text)
            else:
                st.error(f"❌ Không thể truy vấn sau {MAX_VLM_RETRIES} lần thử. Vui lòng thử lại sau.")

# TAB 4: CSV CATALOG
with tab_data:
    st.subheader(f"📁 Bảng Bóc Tách Chuẩn EduViolence 18 Cột ({selected_dataset_name})")
    if not data:
        st.info("Chưa có dữ liệu cho CSDL này.")
    else:
        rows_18 = []
        for idx, d in enumerate(data, 1):
            fn = d.get("file_name", f"Video_{idx}.mp4")
            v_path = find_actual_video_path(fn)
            props = get_video_properties(v_path)
            
            an = d.get("analysis", {})
            ext = an.get("extracted_data", {})
            main_cat = ext.get("main_category", "Walking")
            act_id = ACTION_ID_MAP.get(main_cat, "A09")
            
            src_type = "AI" if fn.startswith("AI_") else ("Movie" if fn.startswith("FI_") or fn.startswith("ST_") else "Real")
            license_type = "AI Generated" if src_type == "AI" else ("Movie Clip" if src_type == "Movie" else "Self")
            
            row = {
                "Video_ID": f"V{idx:06d}",
                "File_Name": fn,
                "Action_ID": act_id,
                "Action_Name": main_cat,
                "Source_Type": src_type,
                "Duration_s": props["duration_s"],
                "FPS": props["fps"],
                "Resolution": props["resolution"],
                "Scene": ext.get("location_setting", "Corridor / Classroom"),
                "Camera_View": "Front / Side",
                "Num_Person": ext.get("total_unique_people", 2),
                "Split": "Train" if idx % 4 != 0 else ("Val" if idx % 4 == 2 else "Test"),
                "Annotator": "Hybrid AI Agent",
                "Reviewer": "Gemini VLM Verifier",
                "Label_Status": "Verified",
                "Collection_Date": "2026-08-25",
                "License": license_type,
                "Notes": ext.get("specific_action_name", "")
            }
            rows_18.append(row)
            
        md_table = "| Video_ID | File_Name | Action_ID | Action_Name | Source | Duration(s) | FPS | Resolution | Scene | Num_Person | Split | Label_Status |\n"
        md_table += "| :--- | :--- | :---: | :--- | :---: | :---: | :---: | :--- | :---: | :---: | :---: |\n"
        for r in rows_18:
            md_table += f"| **`{r['Video_ID']}`** | `{r['File_Name']}` | `{r['Action_ID']}` | **`{r['Action_Name']}`** | `{r['Source_Type']}` | `{r['Duration_s']}` | `{r['FPS']}` | `{r['Resolution']}` | {r['Scene']} | `{r['Num_Person']}` | `{r['Split']}` | `{r['Label_Status']}` |\n"
        st.markdown(md_table)
        
        out_buf = io.StringIO()
        fieldnames = [
            "Video_ID", "File_Name", "Action_ID", "Action_Name", "Source_Type", 
            "Duration_s", "FPS", "Resolution", "Scene", "Camera_View", 
            "Num_Person", "Split", "Annotator", "Reviewer", "Label_Status", 
            "Collection_Date", "License", "Notes"
        ]
        writer = csv.DictWriter(out_buf, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows_18)
        csv_bytes = out_buf.getvalue().encode('utf-8-sig')
        
        clean_name = selected_dataset_name.split()[-1].replace("(", "").replace(")", "")
        st.download_button(
            label=f"📥 Tải Tệp CSV Chuẩn 18 Cột EduViolence ({clean_name})",
            data=csv_bytes,
            file_name=f"EduViolence_{clean_name}_SourceCatalog.csv",
            mime="text/csv",
            type="primary",
            use_container_width=True
        )