import os
import json

DATA_DIR = r'E:\Agent\data'

# Map report file -> expected category
REPORT_MAP = {
    'report_Punching.json': 'Punching',
    'report_Kicking.json': 'Kicking',
    'report_Slapping.json': 'Slapping',
    'report_Pushing_Shoving.json': 'Pushing/Shoving',
    'report_Hair_pulling.json': 'Hair pulling',
    'report_Wrestling_down.json': 'Wrestling down / Throwing to the ground',
    'report_Group_fighting.json': 'Group fighting / Mob beating',
    'report_Threatening_weapon.json': 'Threatening with a dangerous weapon',
    'report_Walking.json': 'Walking',
    'report_Jogging_Running.json': 'Jogging / Running',
    'report_Standing_still.json': 'Standing still',
    'report_Sitting.json': 'Sitting',
    'report_Playing_sports.json': 'Playing sports',
    'report_Handshaking.json': 'Handshaking',
    'report_Peaceful_gathering.json': 'Peaceful gathering',
    'report_Dancing.json': 'Dancing',
}

# Map category -> test folder
CAT_TO_FOLDER = {
    'Punching': r'E:\test\Punching',
    'Kicking': r'E:\test\Kicking',
    'Slapping': r'E:\test\Slapping',
    'Pushing/Shoving': r'E:\test\Pushing or Shoving',
    'Hair pulling': r'E:\test\Hair pulling',
    'Wrestling down / Throwing to the ground': r'E:\test\Wrestling down or Throwing to the ground',
    'Group fighting / Mob beating': r'E:\test\Group fighting or Mob beating',
    'Threatening with a dangerous weapon': r'E:\test\Threatening with a dangerous weapon',
    'Walking': r'E:\test\Walking',
    'Jogging / Running': r'E:\test\Jogging or Running',
    'Standing still': r'E:\test\Standing still',
    'Sitting': r'E:\test\Sitting',
    'Playing sports': r'E:\test\Playing sports',
    'Handshaking': r'E:\test\Handshaking',
    'Peaceful gathering': r'E:\test\Peaceful gathering',
    'Dancing': r'E:\test\Dancing',
}

print("\n[DEBUG] Kiem tra thu muc test:")
for cat, folder in CAT_TO_FOLDER.items():
    exists = os.path.exists(folder)
    count = len([f for f in os.listdir(folder) if f.endswith('.mp4')]) if exists else 0
    print(f"  {'OK' if exists else 'XX'} {cat:<50} {count} videos  ({folder})")

# BUOC 1: Build ground truth tu folders
gt = {}  # filename -> true_category
for cat, folder in CAT_TO_FOLDER.items():
    if not os.path.exists(folder):
        continue
    for f in os.listdir(folder):
        if f.lower().endswith('.mp4'):
            gt[f] = cat

print(f"\n[DEBUG] Ground truth: {len(gt)} video trong {len(CAT_TO_FOLDER)} folders")

# BUOC 2: Duyet tat ca report JSON, tim video bi du doan khac nhan
print("\n[DEBUG] Kiem tra report files:")
total = 0
wrong_list = []
per_cat_total = {}
per_cat_wrong = {}

for rfile, report_cat in REPORT_MAP.items():
    fpath = os.path.join(DATA_DIR, rfile)
    if not os.path.exists(fpath):
        print(f"  XX {rfile} - KHONG TON TAI")
        continue
    with open(fpath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    print(f"  OK {rfile:<45} {len(data)} items")

    for item in data:
        fn = item.get('file_name', '')
        pred = item.get('analysis', {}).get('extracted_data', {}).get('main_category', '')
        conf = item.get('analysis', {}).get('confidence_score', 0)
        danger = item.get('analysis', {}).get('extracted_data', {}).get('danger_severity_score', 0)
        total += 1

        # Tim ground truth tu folder
        true_label = gt.get(fn, None)
        if true_label is None:
            true_label = report_cat  # Fallback

        if true_label not in per_cat_total:
            per_cat_total[true_label] = 0
            per_cat_wrong[true_label] = 0
        per_cat_total[true_label] += 1

        if pred != true_label:
            per_cat_wrong[true_label] += 1
            wrong_list.append({
                'file': fn,
                'true': true_label,
                'pred': pred,
                'conf': conf,
                'danger': danger,
                'report_file': rfile,
            })

# BUOC 3: In ket qua
correct = total - len(wrong_list)
sep = "=" * 105
sep2 = "-" * 105

print()
print(sep)
print("  KET QUA PHAN TICH DO CHINH XAC")
print(sep)
print(f"  Tong video trong reports : {total}")
print(f"  Tong video ground truth  : {len(gt)}")
if total > 0:
    print(f"  DUNG (pred == GT)        : {correct} ({correct/total*100:.1f}%)")
    print(f"  SAI  (pred != GT)        : {len(wrong_list)} ({len(wrong_list)/total*100:.1f}%)")
print(sep)

# Per-category
print()
print(sep2)
print(f"{'Nhan (Ground Truth)':<52} {'Tong':<8} {'Dung':<8} {'Sai':<8} {'Acc':<8}")
print(sep2)
for cat in sorted(per_cat_total.keys()):
    t = per_cat_total[cat]
    w = per_cat_wrong.get(cat, 0)
    c = t - w
    acc = c / t * 100 if t > 0 else 0
    flag = " <<<" if acc < 80 else ""
    print(f"{cat:<52} {t:<8} {c:<8} {w:<8} {acc:.1f}%{flag}")

# Wrong list - grouped
if wrong_list:
    print()
    print(sep2)
    print(f"  CHI TIET {len(wrong_list)} VIDEO BI DU DOAN SAI:")
    print(sep2)

    wrong_sorted = sorted(wrong_list, key=lambda x: (x['true'], x['pred']))
    current_gt = ""
    for i, w in enumerate(wrong_sorted, 1):
        if w['true'] != current_gt:
            current_gt = w['true']
            print(f"\n  [{current_gt}]  ({per_cat_wrong[current_gt]} sai / {per_cat_total[current_gt]} tong)")
        cs = f"{w['conf']*100:.0f}%" if isinstance(w['conf'], float) and w['conf'] <= 1 else f"{w['conf']}"
        print(f"    {i:>3}. {w['file']:<42} GT={w['true']:<20} -> PRED={w['pred']:<20} conf={cs} danger={w['danger']}")

    # Confusion matrix
    print()
    print(sep2)
    print("  MA TRAN NHAM LAN:")
    print(sep2)
    confusion = {}
    for w in wrong_list:
        key = (w['true'], w['pred'])
        confusion[key] = confusion.get(key, 0) + 1
    for (gt_l, pred_l), cnt in sorted(confusion.items(), key=lambda x: -x[1]):
        print(f"    {gt_l:<40} --->  {pred_l:<30} x{cnt}")
else:
    print("\n  KHONG CO VIDEO NAO BI DU DOAN SAI!")

print()
print(sep)