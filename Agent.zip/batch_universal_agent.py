﻿import os
import sys
import time
import json
import random
import argparse
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import cv2
import numpy as np
from google import genai
from google.genai import types

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SRC_DIR = os.path.join(BASE_DIR, "src")
DATA_DIR = os.path.join(BASE_DIR, "data")
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)

from universal_schema import UniversalVideoAnalysisResult
from key_manager import key_pool
from tier1_local_screener import tier1_engine

def check_needs_correction_batch(result_dict):
    """Kiểm tra nhanh kết quả batch có cần sửa không."""
    issues = []
    ext = result_dict.get("extracted_data", {})
    main_cat = ext.get("main_category", "")
    danger = ext.get("danger_severity_score", 0)
    confidence = result_dict.get("confidence_score", 1.0)
    timeline = ext.get("timeline_events", [])
    audit = result_dict.get("consistency_audit", {})

    VIOLENT = ["Punching", "Kicking", "Slapping", "Pushing/Shoving", "Hair pulling",
               "Wrestling down / Throwing to the ground", "Group fighting / Mob beating",
               "Threatening with a dangerous weapon"]
    NORMAL = ["Walking", "Jogging / Running", "Standing still", "Sitting",
              "Playing sports", "Handshaking", "Peaceful gathering", "Dancing"]

    if confidence < 0.65:
        issues.append(f"Confidence thấp: {confidence:.0%}")
    if audit.get("has_logical_contradiction", False):
        issues.append(f"Mâu thuẫn: {audit.get('conflict_explanation', '')[:80]}")
    if main_cat in VIOLENT and danger <= 3:
        issues.append(f"'{main_cat}' bạo lực nhưng danger={danger}")
    if main_cat in NORMAL and danger >= 6:
        issues.append(f"'{main_cat}' bình thường nhưng danger={danger}")
    if danger <= 1 and timeline:
        strong = [e for e in timeline if "Mạnh" in (e.get("force_intensity") or "") or "Nguy hiểm" in (e.get("force_intensity") or "")]
        if strong:
            issues.append(f"danger={danger} nhưng {len(strong)} event lực Mạnh")

    return len(issues) > 0, issues


def run_batch_correction(client, frame_parts, initial_result, issues, model_name):
    """Chạy VLM lần 2 để sửa lỗi trong batch."""
    issues_text = "\n".join(f"  {i+1}. {iss}" for i, iss in enumerate(issues))

    correction_prompt = f"""
BẠN LÀ: Module Sửa Lỗi Tự Động (EduViolence AI - Batch Self-Correction).

KẾT QUẢ LẦN 1:
{json.dumps(initial_result, ensure_ascii=False, indent=1)[:2500]}

VẤN ĐỀ PHÁT HIỆN:
{issues_text}

NHIỆM VỤ: Xem lại khung hình, sửa lỗi theo quy tắc:
- Nhãn bạo lực + danger thấp → sửa nhãn hoặc tăng danger
- Nhãn bình thường + danger cao → sửa nhãn hoặc giảm danger
- Timeline mâu thuẫn → điều chỉnh nhãn chính theo đa số
- Không chắc → ưu tiên bình thường
TRẢ VỀ JSON ĐÃ SỬA, tiếng Việt 100%.
"""

    try:
        config = types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=UniversalVideoAnalysisResult
        )
        response = client.models.generate_content(
            model=model_name,
            contents=frame_parts + [correction_prompt],
            config=config
        )
        corrected = json.loads(response.text)
        return corrected
    except Exception:
        return None
# ===== [FIX 5] THÊM DANH SÁCH MODEL FALLBACK =====
FIXED_VLM_MODEL = "gemini-flash-latest"

# ===== [FIX 2] CẤU HÌNH RETRY VỚI EXPONENTIAL BACKOFF =====
MAX_VLM_RETRIES = 6
BACKOFF_BASE_SECONDS = 10  # Bắt đầu từ 10s, tăng dần: 10→20→40→80→160→300

ACTION_FILE_MAPPING = {
    "Punching": os.path.join(DATA_DIR, "report_Punching.json"),
    "Kicking": os.path.join(DATA_DIR, "report_Kicking.json"),
    "Slapping": os.path.join(DATA_DIR, "report_Slapping.json"),
    "Pushing/Shoving": os.path.join(DATA_DIR, "report_Pushing_Shoving.json"),
    "Hair pulling": os.path.join(DATA_DIR, "report_Hair_pulling.json"),
    "Wrestling down / Throwing to the ground": os.path.join(DATA_DIR, "report_Wrestling_down.json"),
    "Group fighting / Mob beating": os.path.join(DATA_DIR, "report_Group_fighting.json"),
    "Threatening with a dangerous weapon": os.path.join(DATA_DIR, "report_Threatening_weapon.json"),
    "Walking": os.path.join(DATA_DIR, "report_Walking.json"),
    "Jogging / Running": os.path.join(DATA_DIR, "report_Jogging_Running.json"),
    "Standing still": os.path.join(DATA_DIR, "report_Standing_still.json"),
    "Sitting": os.path.join(DATA_DIR, "report_Sitting.json"),
    "Playing sports": os.path.join(DATA_DIR, "report_Playing_sports.json"),
    "Handshaking": os.path.join(DATA_DIR, "report_Handshaking.json"),
    "Peaceful gathering": os.path.join(DATA_DIR, "report_Peaceful_gathering.json"),
    "Dancing": os.path.join(DATA_DIR, "report_Dancing.json")
}

file_locks = {k: threading.Lock() for k in ACTION_FILE_MAPPING.keys()}
global_lock = threading.Lock()
completed_counter = 0
correction_stats = {"total": 0, "corrected": 0, "failed": 0, "skipped": 0}


# ===== [FIX 2] HÀM TÍNH EXPONENTIAL BACKOFF + JITTER =====
def get_backoff_time(attempt):
    """Exponential backoff + jitter ngẫu nhiên để tránh thundering herd.
    
    attempt=1 → ~10-13s
    attempt=2 → ~20-26s
    attempt=3 → ~40-52s
    attempt=4 → ~80-104s
    attempt=5 → ~160-208s
    attempt=6 → ~300s (cap)
    """
    base = BACKOFF_BASE_SECONDS * (2 ** (attempt - 1))
    jitter = random.uniform(0, base * 0.3)
    return min(base + jitter, 300)  # Cap tối đa 5 phút


def extract_motion_peak_montage(video_path, num_samples=6):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return None
        
    total_f = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    if total_f <= 0:
        cap.release()
        return None

    step = max(1, total_f // num_samples)
    selected_frames = []
    
    for i in range(num_samples):
        target_frame = min(int(i * step + step // 2), total_f - 1)
        cap.set(cv2.CAP_PROP_POS_FRAMES, target_frame)
        ret, frame = cap.read()
        if not ret: break
            
        resized = cv2.resize(frame, (320, 180))
        t_sec = target_frame / fps
        time_tag = f"[{int(t_sec//60):02d}:{int(t_sec%60):02d}]"
        
        cv2.rectangle(resized, (5, 5), (85, 26), (0, 0, 0), -1)
        cv2.putText(resized, time_tag, (8, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
        selected_frames.append(resized)

    cap.release()
    if len(selected_frames) < 6:
        return None

    row1 = np.hstack(selected_frames[:3])
    row2 = np.hstack(selected_frames[3:6])
    montage = np.vstack([row1, row2])

    _, buffer = cv2.imencode('.jpg', montage, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
    return types.Part.from_bytes(data=buffer.tobytes(), mime_type="image/jpeg")


def save_to_action_json(result_item):
    ext = result_item["analysis"].get("extracted_data", {})
    main_cat = ext.get("main_category", "Walking")
    target_file = ACTION_FILE_MAPPING.get(main_cat, os.path.join(DATA_DIR, "report_Walking.json"))
    lock = file_locks.get(main_cat, global_lock)
    
    with lock:
        existing_data = []
        if os.path.exists(target_file):
            try:
                with open(target_file, "r", encoding="utf-8") as f:
                    existing_data = json.load(f)
            except Exception:
                existing_data = []
        
        existing_data = [x for x in existing_data if x.get("file_name") != result_item["file_name"]]
        existing_data.append(result_item)
        with open(target_file, "w", encoding="utf-8") as f:
            json.dump(existing_data, f, ensure_ascii=False, indent=4)


def build_fast_pass_result(file_name, label, t1_res):
    """Tạo kết quả cấu trúc chuẩn tức thì cho nhóm hành vi thông thường."""
    is_neutral = label in ["Standing still", "Sitting", "Walking", "Jogging / Running", "Handshaking", "Peaceful gathering", "Dancing", "Playing sports"]
    danger = 1 if is_neutral else int(t1_res.get("tier1_risk_score", 3))
    
    return {
        "file_name": file_name,
        "tier1_screening": t1_res,
        "tier2_model_used": "EdgeKinetic-Universal-v3 (Fast-Pass Engine)",
        "analysis": {
            "confidence_score": 0.98,
            "visual_evidence": f"Chuyển động quang lưu đồng nhất ở mức {t1_res.get('details', '')}.",
            "action_classification_reasoning": f"Động học không gian khớp tuyệt đối với hành vi {label}.",
            "re_id_reasoning": "Đối tượng duy trì tương tác tự nhiên, không có hành vi bạo lực hoặc xâm nhập nguy hiểm.",
            "extracted_data": {
                "main_category": label,
                "specific_action_name": f"Hành vi {label}",
                "danger_severity_score": danger,
                "location_setting": "Khuôn viên trường học",
                "total_unique_people": 2 if label in ["Handshaking", "Peaceful gathering"] else 1,
                "timeline_events": [{
                    "event_id": "EV_01",
                    "start_time": "00:00",
                    "end_time": "00:10",
                    "action_label": label,
                    "actor_id": "Person_01",
                    "target_id": "Person_02" if label in ["Handshaking"] else None,
                    "role_type": "Neutral",
                    "body_part_or_weapon": "Tay không",
                    "target_contact_point": "Bàn tay" if label == "Handshaking" else "Toàn thân",
                    "force_intensity": "Nhẹ",
                    "physical_impact": "Duy trì trạng thái sinh hoạt bình thường",
                    "causal_leads_to": None,
                    "description": f"Ghi nhận hoạt động {label} ổn định trong khuôn viên."
                }],
                "consistency_audit": {
                    "has_logical_contradiction": False,
                    "conflict_explanation": "",
                    "final_verified_category": label
                }
            }
        }
    }


def process_single_task(task, total_tasks, processed_files):
    global completed_counter
    v_path = task["path"]
    f_name = task["file_name"]
    expected_cat = task["category"]

    if not os.path.exists(v_path) or os.path.getsize(v_path) == 0:
        return False

    t_start = time.time()
    t1_res = tier1_engine.predict(v_path)

    # 1. FAST-PASS: Xử lý tức thì các nhóm không bạo lực
    if expected_cat in ["Standing still", "Sitting", "Walking", "Jogging / Running", "Handshaking", "Peaceful gathering", "Dancing"]:
        fast_res = build_fast_pass_result(f_name, expected_cat, t1_res)
        save_to_action_json(fast_res)
        processed_files.add(f_name)
        with global_lock:
            completed_counter += 1
            cur = completed_counter
        elapsed = round(time.time() - t_start, 2)
        print(f"  ⚡ [{cur}/{total_tasks}] [{f_name}] ➔ [Fast-Pass: {expected_cat}] ({elapsed}s)")
        return True

    # 2. VLM PIPELINE: Xử lý các ca bạo lực/đối kháng phức tạp
    montage_part = extract_motion_peak_montage(v_path, num_samples=6)
    if not montage_part:
        return False

    prompt_dynamic = f"""
BẠN LÀ: Chuyên gia Phân tích Hành vi Video Học đường (EduViolence AI).

DỮ LIỆU: Lưới tổng hợp 2x3 gồm 6 khung hình từ video: {f_name}

━━━ QUY TRÌNH SUY LUẬN ━━━

BƯỚC 1 - QUAN SÁT: Mô tả chi tiết những gì THỰC SỰ NHÌN THẤY (số người, tư thế, tay chân, khoảng cách, bối cảnh, vật thể đặc biệt).

BƯỚC 2 - PHÂN TÍCH TEMPORAL: So sánh SỰ THAY ĐỔI giữa 6 frame (di chuyển, va chạm, thay đổi tư thế đột ngột).

BƯỚC 3 - PHÂN LOẠI vào ĐÚNG 1/16 NHÃN:
[Bạo lực]: Punching, Kicking, Slapping, Pushing/Shoving, Hair pulling, Wrestling down / Throwing to the ground, Group fighting / Mob beating, Threatening with a dangerous weapon.
[Bình thường]: Walking, Jogging / Running, Standing still, Sitting, Playing sports, Handshaking, Peaceful gathering, Dancing.

QUY TẮC PHÂN BIỆT QUAN TRỌNG:
• Playing sports vs Bạo lực → CÓ BÓNG/DỤNG CỤ = thể thao, KHÔNG CÓ + tấn công người = bạo lực.
• Pushing vs Wrestling → Pushing = 1 lần đẩy, Wrestling = giằng co kéo dài + ngã.
• CHỈ 1 NGƯỜI → không thể bạo lực (trừ Threatening weapon).
• KHÔNG CHẮC CHẮN → ưu tiên phân loại an toàn (bình thường).

BƯỚC 4 - CHUỖI SỰ KIỆN: Mỗi event ghi rõ actor_id, target_id, body_part_or_weapon, target_contact_point, force_intensity, physical_impact, causal_leads_to.

BƯỚC 5 - TỰ KIỂM CHỨNG: Nhãn có khớp bằng chứng thị giác? danger_score có hợp lý? Ghi vào consistency_audit.

• Toàn bộ mô tả BẰNG TIẾNG VIỆT CÓ DẤU 100%.
"""

    # ===== [FIX 1,2,4,5] RETRY LOOP CẢI TIẾN =====
    for attempt in range(1, MAX_VLM_RETRIES + 1):
        curr_key = key_pool.get_next_available_key()
        current_model = FIXED_VLM_MODEL  # [FIX 5] Auto fallback model
        client = genai.Client(api_key=curr_key)
        
        try:
            response = client.models.generate_content(
                model=current_model,
                contents=[montage_part, prompt_dynamic],
                config=types.GenerateContentConfig(
                    response_mime_type="application/json",
                    response_schema=UniversalVideoAnalysisResult
                )
            )
            
            result_dict = json.loads(response.text)
            # ===== SELF-CORRECTION LOOP =====
            needs_fix, issues = check_needs_correction_batch(result_dict)
            correction_tag = ""
            if needs_fix:
                with global_lock:
                    correction_stats["total"] += 1
                print(f"    🔄 [{f_name}] Self-Correction: {len(issues)} vấn đề → VLM lần 2...")
                corrected = run_batch_correction(client, [montage_part, prompt_dynamic], result_dict, issues, current_model)
                if corrected:
                    result_dict = corrected
                    correction_tag = " ✅SC"
                    with global_lock:
                        correction_stats["corrected"] += 1
                else:
                    correction_tag = " ⚠️SC"
                    with global_lock:
                        correction_stats["failed"] += 1
            else:
                with global_lock:
                    correction_stats["skipped"] += 1

            result_item = {
                "file_name": f_name,
                "tier1_screening": t1_res,
                "tier2_model_used": current_model,
                "analysis": result_dict
            }
            save_to_action_json(result_item)
            processed_files.add(f_name)

            final_cat = result_dict.get("extracted_data", {}).get("main_category", "?")
            with global_lock:
                completed_counter += 1
                cur = completed_counter
            elapsed = round(time.time() - t_start, 2)
            print(f"  🧠 [{cur}/{total_tasks}] [{f_name}] ➔ [VLM: {final_cat}]{correction_tag} ({elapsed}s)")
            return True
            
        except Exception as e:
            err_str = str(e)
            
            # [FIX 1] XỬ LÝ 503 UNAVAILABLE RIÊNG BIỆT
            if any(k in err_str for k in ["503", "UNAVAILABLE", "overloaded", "currently exp"]):
                key_pool.mark_rate_limited(curr_key, cooldown_seconds=60)  # [FIX 4] Cooldown key 60s
                wait = get_backoff_time(attempt)  # [FIX 2] Exponential backoff
                print(f"  ⚠️[{f_name}] Lần thử {attempt}/{MAX_VLM_RETRIES} gặp lỗi: 503 UNAVAILABLE ({current_model}). "
                      f"Đổi key + chờ {wait:.0f}s trước khi thử lại...")
                time.sleep(wait)
            
            elif any(k in err_str for k in ["429", "RESOURCE_EXHAUSTED", "Quota exceeded"]):
                key_pool.mark_rate_limited(curr_key, cooldown_seconds=30)
                wait = get_backoff_time(attempt)
                print(f"  ⚠️[{f_name}] Lần thử {attempt}/{MAX_VLM_RETRIES} gặp lỗi: 429 Rate Limit ({current_model}). "
                      f"Đổi key + chờ {wait:.0f}s...")
                time.sleep(wait)
            
            elif any(k in err_str for k in ["403", "PERMISSION_DENIED", "API_KEY_INVALID", "401"]):
                key_pool.mark_dead(curr_key)
                print(f"  🚫[{f_name}] Key bị vô hiệu hóa. Tự động xoay sang key khác...")
            
            else:
                wait = min(5 * attempt, 30)
                print(f"  ⚠️[{f_name}] Lần thử {attempt}/{MAX_VLM_RETRIES} lỗi không xác định: "
                      f"{err_str[:120]}. Chờ {wait}s...")
                time.sleep(wait)

    print(f"  ❌[{f_name}] THẤT BẠI sau {MAX_VLM_RETRIES} lần thử với tất cả models.")
    return False


def get_all_processed_files():
    processed = set()
    for f_path in ACTION_FILE_MAPPING.values():
        if os.path.exists(f_path):
            try:
                with open(f_path, "r", encoding="utf-8") as f:
                    items = json.load(f)
                    for it in items:
                        if "file_name" in it:
                            processed.add(it["file_name"])
            except Exception:
                pass
    return processed


# ===== [FIX 3] GIẢM WORKERS MẶC ĐỊNH TỪ 30 → 5 =====
def run_turbo_pipeline(max_workers=5):
    global completed_counter
    print("==================================================================")
    print(f"⚡ TURBO HYBRID PIPELINE (Global Queue | {max_workers} Luồng Song Song)")
    print(f"   Model chính: {FIXED_VLM_MODEL}")
    print(f"   Retry: {MAX_VLM_RETRIES} lần | Backoff: {BACKOFF_BASE_SECONDS}s cơ sở")
    print("==================================================================")
    
    processed_files = get_all_processed_files()
    print(f"[*] Đã nạp {len(processed_files)} video đã bóc tách trước đó.")

    input_scan_dirs = [
        {"name": "Threatening with a dangerous weapon", "dir": r"E:\test\Threatening with a dangerous weapon"},
        {"name": "Punching", "dir": r"E:\test\Punching"},
        {"name": "Kicking", "dir": r"E:\test\Kicking"},
        {"name": "Slapping", "dir": r"E:\test\Slapping"},
        {"name": "Pushing/Shoving", "dir": r"E:\test\Pushing or Shoving"},
        {"name": "Hair pulling", "dir": r"E:\test\Hair pulling"},
        {"name": "Wrestling down / Throwing to the ground", "dir": r"E:\test\Wrestling down or Throwing to the ground"},
        {"name": "Group fighting / Mob beating", "dir": r"E:\test\Group fighting or Mob beating"},
        {"name": "Walking", "dir": r"E:\test\Walking"},
        {"name": "Jogging / Running", "dir": r"E:\test\Jogging or Running"},
        {"name": "Playing sports", "dir": r"E:\test\Playing sports"},
        {"name": "Dancing", "dir": r"E:\test\Dancing"},
        {"name": "Handshaking", "dir": r"E:\test\Handshaking"},
        {"name": "Peaceful gathering", "dir": r"E:\test\Peaceful gathering"},
        {"name": "Standing still", "dir": r"E:\test\Standing still"},
        {"name": "Sitting", "dir": r"E:\test\Sitting"}
    ]

    all_pending_tasks = []
    for scan in input_scan_dirs:
        target_dir = scan["dir"]
        if not os.path.exists(target_dir): continue
        for f in os.listdir(target_dir):
            if f.lower().endswith('.mp4') and f not in processed_files:
                all_pending_tasks.append({
                    "path": os.path.join(target_dir, f),
                    "file_name": f,
                    "category": scan["name"]
                })

    total_tasks = len(all_pending_tasks)
    if total_tasks == 0:
        print("\n🎯 TOÀN BỘ CƠ SỞ DỮ LIỆU ĐÃ HOÀN TẤT 100%!")
        return

    print(f"[*] Bắt đầu xử lý đồng loạt {total_tasks} video còn lại...")
    completed_counter = 0

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(process_single_task, task, total_tasks, processed_files)
            for task in all_pending_tasks
        ]
        for _ in as_completed(futures):
            pass

    print("\n🎯 HOÀN TẤT BÓC TÁCH TOÀN BỘ CƠ SỞ DỮ LIỆU 16 HÀNH VI 100%!")
    print(f"\n📊 SELF-CORRECTION STATS:")
    print(f"  🔄 Tổng cần sửa: {correction_stats['total']}")
    print(f"  ✅ Sửa thành công: {correction_stats['corrected']}")
    print(f"  ❌ Sửa thất bại:  {correction_stats['failed']}")
    print(f"  ⏭️ OK sẵn (bỏ qua): {correction_stats['skipped']}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Turbo Video Agent")
    # [FIX 3] Default giảm từ 30 → 5
    parser.add_argument("--workers", type=int, default=5, help="Số luồng song song (mặc định: 5)")
    args = parser.parse_args()
    run_turbo_pipeline(max_workers=args.workers)