﻿import os
import re
import time
import threading
from dotenv import load_dotenv

SRC_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(SRC_DIR)
ENV_PATH = os.path.join(ROOT_DIR, ".env")
load_dotenv(ENV_PATH, encoding="utf-8-sig")

BUILTIN_KEYS = [
    "AQ.Ab8RN6LeFhPDpyQdSDbxefM2sWHe1YFdLtq7D7wlwFlDp40Rag",
    "AQ.Ab8RN6K90UyvtxfTPkrZKcxL97wNthatR1r9VXjNk0k5ujn4Rw",
    "AQ.Ab8RN6KmMOpHIcjenfF-5ELI2prj7Kqg7qrK6TtXuTfzLAsusA",
    "AQ.Ab8RN6LqAlUhro4lEzj7vmTjiPOGsxuz4cpIwaUFK5MBbKwImA",
    "AQ.Ab8RN6K8RiFUKsBAanZI56qHygpzBo-giiBHpN6VPUMl1AkKGQ",
    "AQ.Ab8RN6K-dzQ6dQ85CKg_BkMaptvFer1sfzOhryrkYnD57N-jiw",
    "AQ.Ab8RN6JQH49QBCI-WCSqClb7h3k9OKyqAyJj-yOhUfJuAPu2rw",
    "AQ.Ab8RN6It9Nzg0uoVRN1D-8csXpotQzI_qLRjtvAnOD7g8owJ2g",
    "AQ.Ab8RN6KT8Myu3MxV2xI83tBsg3dP3JbgVyWdNa10pCPJpsOZEQ",
    "AQ.Ab8RN6JXUfgdpmrbunGZ-9ROGXZV7wnwl2SdPld9DpYT4TR3dg",
    "AQ.Ab8RN6LmH9z5WIt5SscJ3ojmaJOUFZLoNjZmvbUGxb4-Po8-ow",
    "AQ.Ab8RN6Kd-yc0NLTvn65MhxtnUmQcyAizNdf4cqkOdtEh7C2-jw",
    "AQ.Ab8RN6KVWcdH4n-KqlQc79ZkfS6nUhPRT1HIwJctGiCH6SKPKA",
    "AQ.Ab8RN6Iveb5vbTYN54CYzFBZaJtq-ZCaPL6q9seZbF87hlLKzw",
    "AQ.Ab8RN6KOt-3o-Cp8EX1IZIUd4b1O9hpPqrpI0-Ji2vYWUV_zVw",
    "AQ.Ab8RN6KhuIbUqAFCbY3Wp9A1ev7v2J75zQc8Xq4iShQcpWqV0w",
    "AQ.Ab8RN6L8mMaKvWA6MvzDsyDyV5Oi-Ie5NvfNiYHjPToApNCYBg",
    "AQ.Ab8RN6Kp0L71t8WCzLOBaZRaZKmeYCPwnnDK5dDFpj-_mwFvTA",
    "AQ.Ab8RN6KJBdEmN45V4KWvTGb8k5oTDqsHsTR_zQwocjlS9CvrUw",
    "AQ.Ab8RN6IL4ylNAevWjiGLWwu7Y73CcCbbNQdJntOagCqZoiNwmg",
    "AQ.Ab8RN6J1b6EugrPGNFth0sAbKh3z4gG2hWzuOTh-qPSs8mWR1w",
    "AQ.Ab8RN6IEiNjVQkhEj4L6Iy5IZxLgbRDYPg5NnbzEL9ikcoMJdQ",
    "AQ.Ab8RN6K0gBJy6XKiRssAbcSoBDJHSDS_rkYZbD62e-9PdCtwIQ",
    "AQ.Ab8RN6K6IcC1uE_oKJdndg6ExlWs90cOANSCEEYozUw5yuu0DA",
    "AQ.Ab8RN6I7tbbmVVIbIIsrdGW5oitJSugJf9G4cdSuXDBab43wtA",
    "AQ.Ab8RN6LHNrLv3OM2F8LfOAootvPE1qUmCwN7s3dmEXVevj_Pxw",
    "AQ.Ab8RN6IMmlizl7UP5Accy3BIha0BknBvPKLZcq5HLA8hwq3Emw",
    "AQ.Ab8RN6JPQb0zyOlhQeAFYOR7AlSpKKs8oWsRJ9BVWFRbm06Giw",
    "AQ.Ab8RN6KgRqh_xyLN_6hbC9pjHIo3rs6XeNUNcEQq6gY9WPRZgw",
    "AQ.Ab8RN6JJVjwQ-B2m_WuuqhMQmtmoyIqksHMTcoJ4fXzwCqxMtQ",
    "AQ.Ab8RN6LE9au1T90eHMVkooD4AaShKTHvIroMPWa0lx85ivsJOg",
    "AQ.Ab8RN6LsLzTboK0luAMNUtSUZKMe6_x2kEKYAs4xkSfeGFjScA",
    "AQ.Ab8RN6KS72i_OgKcPdvMD5-ErS4Fv2T4DfvEa1y38Z6AdvE6zQ",
    "AQ.Ab8RN6KHeuDl7XpT5Y-oWNkNH_fPCr8ab6TbokliiSCD2dC7jg",
    "AQ.Ab8RN6Lu2-0p5Nkb5AxHrfqMk5VhTAciUdLhl30d_MwyUuh6ug",
    "AQ.Ab8RN6L5L-yXQSLkmObUsfxYtLlla2Zdm7sYKcrgyYFs8zHRCQ",
    "AQ.Ab8RN6LOEAZpOIl3oazaoT9-CKciYUolIKylpoeeqhUvCBjXsA",
    "AIzaSyCtwVEIi58RjgIUfnzqUeEis7VXv6jdNvg",
    "AQ.Ab8RN6Kpk_q7kAA0z5rzwa8340LJUYv7BODijwdoyqy3tVr0RA",
    "AQ.Ab8RN6Ifv4rZB9jDqtGnWnf476Yw8skx-jPg4tEo7AFxXmluxQ",
    "AQ.Ab8RN6KyElirc977UTVfvB0SdwAkaKliD4NuF6tqRT6mf0EGsw"
]


class RoundRobinKeyManager:
    def __init__(self):
        self.lock = threading.Lock()
        self.keys = []
        self.dead_keys = set()          # Key chết vĩnh viễn (403/401)
        self.rate_limited = {}           # [MỚI] Key đang cooldown: {key: timestamp_hết_hạn}
        self.req_counter = 0
        self._load_keys()

    def _load_keys(self):
        extracted = []
        if os.path.exists(ENV_PATH):
            try:
                with open(ENV_PATH, "r", encoding="utf-8-sig") as f:
                    for line in f:
                        line = line.strip()
                        if "=" in line and not line.startswith("#"):
                            val = line.split("=", 1)[1].strip().strip('"').strip("'")
                            parts = [p.strip() for p in re.split(r'[,;\s]+', val) if p.strip()]
                            extracted.extend(parts)
            except Exception:
                pass

        all_candidate = extracted + BUILTIN_KEYS
        seen = set()
        clean = []
        for k in all_candidate:
            if k and len(k) >= 25 and k not in seen:
                clean.append(k)
                seen.add(k)
                
        self.keys = clean
        print(f"🔑 [Key Manager] Đã nạp thành công {len(self.keys)} API Keys hoạt động!")

    def _cleanup_expired_cooldowns(self):
        """Dọn dẹp các key đã hết thời gian cooldown → cho phép dùng lại."""
        now = time.time()
        expired = [k for k, expire_at in self.rate_limited.items() if now >= expire_at]
        for k in expired:
            del self.rate_limited[k]
            masked = k[:6] + "..." + k[-4:]
            print(f"  🔓 [Key Recovered] {masked} đã hết cooldown, sẵn sàng dùng lại.")

    def get_next_available_key(self):
        """Lấy key tiếp theo còn khả dụng (không chết, không đang cooldown).
        
        Nếu TẤT CẢ key đều đang cooldown → CHỜ cho đến khi key sớm nhất hết cooldown.
        """
        with self.lock:
            # Bước 1: Dọn dẹp key đã hết cooldown
            self._cleanup_expired_cooldowns()
            
            # Bước 2: Lọc key khả dụng (không chết + không đang cooldown)
            active = [k for k in self.keys 
                      if k not in self.dead_keys 
                      and k not in self.rate_limited]
            
            # Bước 3: Nếu TẤT CẢ key đều bận → CHỜ key sớm nhất hết cooldown
            if not active:
                if self.rate_limited:
                    # Tìm key sẽ hết cooldown sớm nhất
                    earliest_key = min(self.rate_limited, key=self.rate_limited.get)
                    wait_seconds = max(0, self.rate_limited[earliest_key] - time.time())
                    
                    if wait_seconds > 0:
                        masked = earliest_key[:6] + "..." + earliest_key[-4:]
                        print(f"  ⏳ [Key Manager] Tất cả key đang cooldown. "
                              f"Chờ {wait_seconds:.0f}s cho {masked} hồi phục...")
                        
                        # Tạm thời mở lock để các thread khác không bị block
                        self.lock.release()
                        time.sleep(wait_seconds + 1)
                        self.lock.acquire()
                    
                    # Sau khi chờ, dọn dẹp lại
                    self._cleanup_expired_cooldowns()
                    active = [k for k in self.keys 
                              if k not in self.dead_keys 
                              and k not in self.rate_limited]
                
                # Nếu vẫn không có key (tất cả dead) → reset dead_keys
                if not active:
                    print(f"  ⚠️ [Key Manager] Reset toàn bộ {len(self.dead_keys)} dead keys.")
                    self.dead_keys.clear()
                    self.rate_limited.clear()
                    active = self.keys

            selected = active[self.req_counter % len(active)]
            self.req_counter += 1
            return selected

    def mark_rate_limited(self, key, cooldown_seconds=30):
        """[MỚI] Tạm ngắt key trong cooldown_seconds giây, sau đó tự động hồi phục.
        
        Dùng cho lỗi 429 (rate limit) và 503 (model overloaded).
        """
        with self.lock:
            expire_at = time.time() + cooldown_seconds
            self.rate_limited[key] = expire_at
            masked = key[:6] + "..." + key[-4:]
            active_count = len([k for k in self.keys 
                               if k not in self.dead_keys 
                               and k not in self.rate_limited])
            print(f"  ⏸️ [Key Cooldown] {masked} tạm ngắt {cooldown_seconds}s | "
                  f"Còn {active_count} keys sẵn sàng")

    def mark_dead(self, key):
        """Đánh dấu key chết vĩnh viễn (403/401/PERMISSION_DENIED)."""
        with self.lock:
            self.dead_keys.add(key)
            # Xóa khỏi rate_limited nếu có (vì đã chết hẳn)
            self.rate_limited.pop(key, None)
            masked = key[:6] + "..." + key[-4:]
            active_count = len([k for k in self.keys 
                               if k not in self.dead_keys 
                               and k not in self.rate_limited])
            print(f"  🚫 [Key Disabled] Vô hiệu hóa {masked} | "
                  f"Còn {active_count} keys sẵn sàng")

    def total_keys(self):
        """Trả về số key còn khả dụng (không chết, không đang cooldown)."""
        with self.lock:
            self._cleanup_expired_cooldowns()
            return len([k for k in self.keys 
                       if k not in self.dead_keys 
                       and k not in self.rate_limited])

    def get_status(self):
        """[MỚI] Trả về trạng thái chi tiết của key pool."""
        with self.lock:
            self._cleanup_expired_cooldowns()
            total = len(self.keys)
            dead = len(self.dead_keys)
            cooling = len(self.rate_limited)
            active = total - dead - cooling
            return {
                "total": total,
                "active": active,
                "cooling_down": cooling,
                "dead": dead
            }


key_pool = RoundRobinKeyManager()