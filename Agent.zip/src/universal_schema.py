﻿from pydantic import BaseModel, Field
from typing import List, Optional

class TimelineEvent(BaseModel):
    event_id: str = Field(description="Mã định danh sự kiện theo chuỗi: EV_01, EV_02, EV_03...")
    start_time: str = Field(description="Mốc thời gian bắt đầu (định dạng MM:SS hoặc 00:00)")
    end_time: str = Field(description="Mốc thời gian kết thúc (định dạng MM:SS hoặc 00:00)")
    action_label: str = Field(description="Nhãn hành vi chuẩn EduViolence (VD: Punching, Kicking, Wrestling down...)")
    
    # Thực thể & Vai trò (Who)
    actor_id: str = Field(description="Chủ thể phát lực: Aggressor_01, Aggressor_02, Intervener_01, Person_01...")
    target_id: Optional[str] = Field(default=None, description="Đối tượng nhận lực: Victim_01, Victim_02...")
    role_type: str = Field(description="Phân loại vai trò: Aggressor | Victim | Intervener | Bystander | Collective_Group")
    
    # Động lực học & Công cụ (How & With What)
    body_part_or_weapon: Optional[str] = Field(default="Tay không", description="Bộ phận phát lực hoặc công cụ sử dụng (VD: Tay phải, Chân trái, Gậy, Ghế, Tay không)")
    target_contact_point: Optional[str] = Field(default="Toàn thân", description="Điểm chịu lực trên cơ thể đối phương (VD: Vùng mặt/đầu, Ngực, Vai/Lưng, Chân)")
    force_intensity: str = Field(default="Trung bình", description="Cường độ phát lực: Nhẹ | Trung bình | Mạnh / Nguy hiểm")
    physical_impact: str = Field(description="Hệ quả vật lý tức thì (VD: Bị mất đà ngã xuống sàn, Lùi lại phòng thủ, Can ngăn thành công)")
    
    # Quan hệ nhân quả tuyến tính (Why / Causality)
    causal_leads_to: Optional[str] = Field(default=None, description="Sự kiện hoặc phản ứng tiếp diễn (VD: Dẫn đến sự kiện can ngăn của bảo vệ EV_02)")
    description: str = Field(description="Mô tả tóm tắt toàn bộ diễn biến vi mô của sự kiện bằng tiếng Việt có dấu")

class ConsistencyAudit(BaseModel):
    has_logical_contradiction: bool = Field(description="True nếu phát hiện mâu thuẫn giữa hành động và vai trò thực thể")
    conflict_explanation: str = Field(description="Giải trình chi tiết nếu có mâu thuẫn logic bằng tiếng Việt")
    final_verified_category: str = Field(description="Nhãn hành vi chuẩn xác cuối cùng sau khi tự phản biện")

class ExtractedData(BaseModel):
    main_category: str = Field(description="Đúng 1 trong 16 nhãn chuẩn EduViolence")
    specific_action_name: str = Field(description="Tên hành vi chi tiết bằng tiếng Việt")
    danger_severity_score: int = Field(description="Thang điểm nguy hiểm an ninh từ 1 đến 10")
    location_setting: str = Field(description="Bối cảnh không gian diễn ra sự việc bằng tiếng Việt")
    total_unique_people: int = Field(description="Tổng số lượng người xuất hiện trong video")
    timeline_events: List[TimelineEvent] = Field(description="Danh sách chuỗi sự kiện đa chiều theo dòng thời gian")
    consistency_audit: ConsistencyAudit = Field(description="Kết quả kiểm định logic tự phản biện CoT")

class UniversalVideoAnalysisResult(BaseModel):
    confidence_score: float = Field(description="Độ tin cậy từ 0.0 đến 1.0")
    visual_evidence: str = Field(description="Bằng chứng thị giác quan sát được bằng tiếng Việt")
    action_classification_reasoning: str = Field(description="Chuỗi suy luận CoT phân loại hành vi bằng tiếng Việt")
    re_id_reasoning: str = Field(description="Chuỗi suy luận gán vai trò Re-ID các đối tượng bằng tiếng Việt")
    extracted_data: ExtractedData
