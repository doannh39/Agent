﻿import json

def generate_single_video_graph_html(record, height=500):
    """Tạo đồ thị quan hệ vi mô độc lập cho đúng 1 video (Live upload hoặc CSDL)."""
    if not record:
        return "<div style='color:#94a3b8;'>Không có dữ liệu đồ thị.</div>"

    fn = record.get("file_name", "Uploaded_Video.mp4")
    analysis = record.get("analysis", {})
    ext = analysis.get("extracted_data", {})
    
    cat = ext.get("main_category", "Walking")
    loc = ext.get("location_setting", "Khuôn viên trường")
    danger = ext.get("danger_severity_score", 1)
    timeline = ext.get("timeline_events", [])

    vis_nodes = []
    vis_edges = []

    # 1. Nút Video Gốc
    color_v = "#dc2626" if danger >= 6 else ("#f59e0b" if danger >= 3 else "#10b981")
    vis_nodes.append({
        "id": "ROOT_VID",
        "label": f"🎬 {fn[:18]}\n[{cat}]",
        "color": {"background": color_v, "border": "#ffffff"},
        "shape": "box",
        "size": 28,
        "font": {"color": "#ffffff", "size": 11, "bold": True},
        "margin": 10
    })

    # 2. Nút Địa Điểm
    vis_nodes.append({
        "id": "LOC_NODE",
        "label": f"📍 {loc[:20]}",
        "color": {"background": "#8b5cf6", "border": "#ffffff"},
        "shape": "diamond",
        "size": 20,
        "font": {"color": "#ffffff", "size": 10, "bold": True}
    })
    vis_edges.append({
        "from": "ROOT_VID", "to": "LOC_NODE", "label": "OCCURRED_AT",
        "color": {"color": "#8b5cf6"}, "arrows": "to", "width": 2.0,
        "font": {"size": 8, "color": "#8b5cf6", "strokeWidth": 0}
    })

    # 3. Chuỗi Nút Sự Kiện & Thực Thể
    prev_ev_id = None
    created_persons = set()
    aggressors = []
    victims = []
    interveners = []

    for idx, ev in enumerate(timeline):
        ev_id = f"EV_{idx+1}"
        t_range = f"{ev.get('start_time','00:00')}-{ev.get('end_time','00:00')}"
        act = ev.get("action_label", cat)
        force = ev.get("force_intensity", "Trung bình")
        weapon = ev.get("body_part_or_weapon", "Tay không")
        contact = ev.get("target_contact_point", "Toàn thân")
        actor = ev.get("actor_id", "Person_01")
        target = ev.get("target_id")

        ev_color = "#ef4444" if "Mạnh" in force or "Nguy hiểm" in force else ("#f59e0b" if "Trung bình" in force else "#0284c7")
        vis_nodes.append({
            "id": ev_id,
            "label": f"⏱️{t_range}\n{act[:15]}",
            "title": f"Vũ khí: {weapon}\nLực: {force}\nVa chạm: {contact}\n{ev.get('physical_impact', '')}",
            "color": {"background": ev_color, "border": "#ffffff"},
            "shape": "hexagon",
            "size": 18,
            "font": {"color": "#ffffff", "size": 9, "bold": True}
        })
        vis_edges.append({
            "from": "ROOT_VID", "to": ev_id, "label": "HAS_EVENT",
            "color": {"color": "#38bdf8"}, "arrows": "to", "width": 1.5,
            "font": {"size": 7, "color": "#38bdf8", "strokeWidth": 0}
        })

        if prev_ev_id:
            rel = "INTERVENES" if "Intervener" in actor else "LEADS_TO"
            vis_edges.append({
                "from": prev_ev_id, "to": ev_id, "label": rel,
                "color": {"color": "#f59e0b"}, "arrows": "to", "width": 2.5,
                "font": {"size": 7, "color": "#f59e0b", "strokeWidth": 0}
            })
        prev_ev_id = ev_id

        # Nút Thực Thể Actor
        if actor not in created_persons:
            created_persons.add(actor)
            p_color = "#dc2626" if "Aggressor" in actor else ("#06b6d4" if "Intervener" in actor else "#3b82f6")
            p_label = f"🥊 {actor}" if "Aggressor" in actor else (f"👮 {actor}" if "Intervener" in actor else f"👤 {actor}")
            vis_nodes.append({
                "id": actor, "label": p_label,
                "color": {"background": p_color, "border": "#ffffff"},
                "shape": "dot", "size": 14, "font": {"color": "#ffffff", "size": 10, "bold": True}
            })
            vis_edges.append({
                "from": "ROOT_VID", "to": actor, "label": "INVOLVES",
                "color": {"color": "#38bdf8"}, "arrows": "to", "width": 1.5,
                "font": {"size": 7, "color": "#38bdf8", "strokeWidth": 0}
            })
            if "Aggressor" in actor: aggressors.append(actor)
            elif "Intervener" in actor: interveners.append(actor)

        vis_edges.append({
            "from": actor, "to": ev_id, "label": "PERFORMS",
            "color": {"color": "#ef4444" if "Aggressor" in actor else "#06b6d4"}, "arrows": "to", "width": 2.0,
            "font": {"size": 7, "color": "#ef4444" if "Aggressor" in actor else "#06b6d4", "strokeWidth": 0}
        })

        # Nút Thực Thể Target (Nạn nhân)
        if target:
            if target not in created_persons:
                created_persons.add(target)
                vis_nodes.append({
                    "id": target, "label": f"🛡️ {target}",
                    "color": {"background": "#ea580c", "border": "#ffffff"},
                    "shape": "dot", "size": 14, "font": {"color": "#ffffff", "size": 10, "bold": True}
                })
                vis_edges.append({
                    "from": "ROOT_VID", "to": target, "label": "INVOLVES",
                    "color": {"color": "#38bdf8"}, "arrows": "to", "width": 1.5,
                    "font": {"size": 7, "color": "#38bdf8", "strokeWidth": 0}
                })
                victims.append(target)

            vis_edges.append({
                "from": ev_id, "to": target, "label": f"IMPACTS",
                "title": f"Va chạm: {contact}",
                "color": {"color": "#ea580c"}, "arrows": "to", "width": 2.0,
                "font": {"size": 7, "color": "#ea580c", "strokeWidth": 0}
            })

    # Quan hệ đối kháng trực tiếp
    for agg in aggressors:
        for vic in victims:
            vis_edges.append({
                "from": agg, "to": vic, "label": "ATTACKS",
                "color": {"color": "#ef4444"}, "arrows": "to", "width": 3.0,
                "font": {"size": 8, "color": "#ef4444", "strokeWidth": 0}
            })
    for itv in interveners:
        for agg in aggressors:
            vis_edges.append({
                "from": itv, "to": agg, "label": "INTERVENES",
                "color": {"color": "#06b6d4"}, "arrows": "to", "width": 3.0,
                "font": {"size": 8, "color": "#06b6d4", "strokeWidth": 0}
            })

    nodes_json = json.dumps(vis_nodes, ensure_ascii=False)
    edges_json = json.dumps(vis_edges, ensure_ascii=False)

    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <script type="text/javascript" src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
        <style type="text/css">
            html, body {{ margin: 0; padding: 0; width: 100%; height: 100%; background-color: #080c14; overflow: hidden; }}
            #singlenetwork {{ width: 100%; height: {height}px; background-color: #080c14; border: 1px solid #1e293b; border-radius: 8px; }}
        </style>
    </head>
    <body>
        <div id="singlenetwork"></div>
        <script type="text/javascript">
            var nodes = new vis.DataSet({nodes_json});
            var edges = new vis.DataSet({edges_json});
            var container = document.getElementById('singlenetwork');
            var data = {{ nodes: nodes, edges: edges }};
            var options = {{
                nodes: {{ borderWidth: 2 }},
                edges: {{
                    smooth: {{ type: 'curvedCW', roundness: 0.15 }},
                    font: {{ align: 'top' }}
                }},
                physics: {{
                    enabled: true,
                    solver: 'forceAtlas2Based',
                    forceAtlas2Based: {{
                        gravitationalConstant: -150,
                        centralGravity: 0.005,
                        springLength: 220,
                        springConstant: 0.03,
                        damping: 0.5,
                        avoidOverlap: 0.8
                    }},
                    stabilization: {{ iterations: 300, fit: true }}
                }},
                interaction: {{
                    hover: true,
                    navigationButtons: true,
                    zoomView: true,
                    tooltipDelay: 200
                }},
                layout: {{
                    improvedLayout: true,
                    randomSeed: 42
                }}
            }};
            var network = new vis.Network(container, data, options);
            network.once('stabilizationIterationsDone', function() {{
                network.fit({{ animation: {{ duration: 500, easingFunction: 'easeInOutQuad' }}, maxZoomLevel: 1.2 }});
            }});
        </script>
    </body>
    </html>
    """


def generate_interactive_graph_html(nodes_dict, edges_list, filter_category=None, max_nodes=180, video_clusters=None):
    vis_nodes = []
    vis_edges = []
    selected_nodes = set()
    selected_edges = []

    if video_clusters:
        matching_vids = []
        for vname, vdata in video_clusters.items():
            if filter_category and filter_category != "ALL":
                if filter_category.lower() in vdata.get("category", "").lower():
                    matching_vids.append((vname, vdata))
            else:
                matching_vids.append((vname, vdata))

        if not matching_vids:
            matching_vids = list(video_clusters.items())

        for vname, vdata in matching_vids:
            if len(selected_nodes) + len(vdata["nodes"]) > max_nodes and len(selected_nodes) > 0:
                break
            selected_nodes.update(vdata["nodes"])
            selected_edges.extend(vdata["edges"])

    if not selected_nodes:
        selected_nodes = set(list(nodes_dict.keys())[:max_nodes])
        selected_edges = edges_list[:max_nodes * 2]

    for nid in selected_nodes:
        if nid not in nodes_dict: continue
        nd = nodes_dict[nid]
        ntype = nd.get("type", "Entity")

        if ntype == "Video":
            danger = nd.get("danger", 1)
            color = "#dc2626" if danger >= 6 else ("#f59e0b" if danger >= 3 else "#10b981")
            shape = "box"; size = 24
            label = f"🎬 {nid[:14]}\n({nd.get('category')})"
        elif ntype == "Event":
            force = nd.get("force_level", "Trung bình")
            color = "#ef4444" if "Mạnh" in force or "Nguy hiểm" in force else ("#f59e0b" if "Trung bình" in force else "#0284c7")
            shape = "hexagon"; size = 18
            weapon_str = f" [{nd.get('weapon')}]" if nd.get('weapon') != "Tay không" else ""
            label = f"⏱️ {nd.get('time')}\n{nd.get('action')}{weapon_str}"
        elif ntype == "Person":
            role = nd.get("role", "")
            if "Aggressor" in role:
                color = "#dc2626"; label = f"🥊 {role}"
            elif "Victim" in role:
                color = "#ea580c"; label = f"🛡️ {role}"
            elif "Intervener" in role:
                color = "#06b6d4"; label = f"👮 Can Ngăn"
            elif "Group" in role:
                color = "#7f1d1d"; label = f"⚠️ Hội Đồng"
            else:
                color = "#3b82f6"; label = f"👤 {role}"
            shape = "dot"; size = 14
        elif ntype == "Location":
            color = "#8b5cf6"; shape = "diamond"; size = 20
            label = f"{nd.get('label', nid)[:20]}"
        else:
            color = "#6b7280"; shape = "ellipse"; size = 12; label = str(nid)[:15]

        vis_nodes.append({
            "id": nid,
            "label": label,
            "title": f"Chi tiết: {nd.get('impact', nd.get('desc', ''))}",
            "color": {"background": color, "border": "#ffffff", "highlight": {"background": "#ffffff", "border": color}},
            "shape": shape,
            "size": size,
            "font": {"color": "#f8fafc", "size": 10, "face": "Segoe UI", "bold": True}
        })

    seen_edges = set()
    for e in selected_edges:
        src, dst, rel = e[0], e[1], e[2]
        edge_key = (src, dst, rel)
        if edge_key in seen_edges: continue
        seen_edges.add(edge_key)

        if src in selected_nodes and dst in selected_nodes:
            if "ATTACKS" in rel or "IMPACTS" in rel:
                edge_color = "#ef4444"; width = 2.8
            elif "INTERVENES" in rel:
                edge_color = "#06b6d4"; width = 2.8
            elif "LEADS_TO" in rel:
                edge_color = "#f59e0b"; width = 2.4
            elif "OCCURRED_AT" in rel:
                edge_color = "#8b5cf6"; width = 1.8
            elif "HAS_EVENT" in rel:
                edge_color = "#38bdf8"; width = 1.8
            else:
                edge_color = "#94a3b8"; width = 1.5

            vis_edges.append({
                "from": src,
                "to": dst,
                "label": rel,
                "arrows": "to",
                "width": width,
                "color": {"color": edge_color, "highlight": "#ffffff"},
                "font": {"color": "#94a3b8", "size": 8, "align": "top", "strokeWidth": 0}
            })

    nodes_json = json.dumps(vis_nodes, ensure_ascii=False)
    edges_json = json.dumps(vis_edges, ensure_ascii=False)

    html_code = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <script type="text/javascript" src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
        <style type="text/css">
            html, body {{ margin: 0; padding: 0; width: 100%; height: 100%; background-color: #080c14; overflow: hidden; }}
            #mynetwork {{ width: 100%; height: 540px; background-color: #080c14; border: 1px solid #1e293b; border-radius: 8px; }}
        </style>
    </head>
    <body>
        <div id="mynetwork"></div>
        <script type="text/javascript">
            var nodes = new vis.DataSet({nodes_json});
            var edges = new vis.DataSet({edges_json});
            var container = document.getElementById('mynetwork');
            var data = {{ nodes: nodes, edges: edges }};
            var options = {{
                nodes: {{ borderWidth: 2 }},
                edges: {{
                    smooth: {{ type: 'curvedCW', roundness: 0.12 }},
                    font: {{ align: 'top' }}
                }},
                physics: {{
                    enabled: true,
                    solver: 'forceAtlas2Based',
                    forceAtlas2Based: {{
                        gravitationalConstant: -100,
                        centralGravity: 0.008,
                        springLength: 180,
                        springConstant: 0.04,
                        damping: 0.45,
                        avoidOverlap: 0.7
                    }},
                    stabilization: {{ iterations: 200, fit: true }}
                }},
                interaction: {{
                    hover: true,
                    navigationButtons: true,
                    zoomView: true,
                    tooltipDelay: 200
                }},
                layout: {{
                    improvedLayout: true,
                    randomSeed: 42
                }}
            }};
            var network = new vis.Network(container, data, options);
            network.once('stabilizationIterationsDone', function() {{
                network.fit({{ animation: {{ duration: 600, easingFunction: 'easeInOutQuad' }}, maxZoomLevel: 1.0 }});
            }});
        </script>
    </body>
    </html>
    """
    return html_code