﻿import os
import glob
import json
import re

SRC_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(SRC_DIR)
DATA_DIR = os.path.join(ROOT_DIR, "data")

HOTSPOT_LOCATIONS = {
    "sân": "📍 Sân Trường / Ngoài Trời",
    "bãi xe": "📍 Bãi Đỗ Xe",
    "hành lang": "📍 Hành Lang",
    "cầu thang": "📍 Cầu Thang",
    "lớp": "📍 Trong Lớp Học",
    "phòng": "📍 Phòng Kín / KTX"
}

# ===== [MỚI] TỪ KHÓA MỞ RỘNG CHO TÌM KIẾM THÔNG MINH =====
KEYWORD_SYNONYMS = {
    "đấm": ["punching", "đấm", "nắm đấm", "thụi", "quả đấm"],
    "đá": ["kicking", "đá", "cú đá", "tống"],
    "tát": ["slapping", "tát", "bạt tai", "vả"],
    "xô": ["pushing", "xô", "đẩy", "giằng co", "shoving"],
    "tóc": ["hair", "tóc", "giật tóc", "kéo tóc", "nắm tóc"],
    "vật": ["wrestling", "vật", "quật", "ngã", "lăn"],
    "hội đồng": ["group", "hội đồng", "đánh hội", "mob", "nhóm"],
    "hung khí": ["weapon", "hung khí", "dao", "gậy", "ghế", "chai", "đe dọa", "threatening"],
    "đầu": ["đầu", "mặt", "trán", "thái dương", "vùng đầu", "vùng mặt"],
    "ngực": ["ngực", "bụng", "sườn"],
    "lưng": ["lưng", "vai", "gáy"],
    "chân": ["chân", "đùi", "gối", "ống chân"],
    "mạnh": ["mạnh", "nguy hiểm", "dữ dội", "hung hãn", "nghiêm trọng"],
    "nhẹ": ["nhẹ", "yếu", "không đáng kể"],
    "bạo lực": ["bạo lực", "tấn công", "đánh", "hành hung", "violence"],
    "bình thường": ["bình thường", "ôn hòa", "đi bộ", "ngồi", "đứng", "chạy", "thể thao"],
}


def normalize_hotspot(loc_text):
    t = (loc_text or "").lower()
    for key, std_loc in HOTSPOT_LOCATIONS.items():
        if key in t: return std_loc
    return "📍 Khuôn Viên Trường"


class KnowledgeGraphRAGEngine:
    def __init__(self):
        self.nodes = {}
        self.edges = []
        self.video_clusters = {}
        self.build_graph_from_reports()

    def build_graph_from_reports(self):
        self.nodes.clear()
        self.edges.clear()
        self.video_clusters.clear()
        
        json_files = glob.glob(os.path.join(DATA_DIR, "report_*.json"))

        for fpath in json_files:
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    records = json.load(f)
                if not isinstance(records, list): continue

                for r in records:
                    if not isinstance(r, dict): continue
                    fn = r.get("file_name", "")
                    an = r.get("analysis", {})
                    ext = an.get("extracted_data", {})
                    
                    cat = ext.get("main_category", "Walking")
                    loc = normalize_hotspot(ext.get("location_setting", ""))
                    danger = ext.get("danger_severity_score", 1)
                    timeline = ext.get("timeline_events", [])

                    # 1. Nút Video
                    self.nodes[fn] = {
                        "type": "Video",
                        "category": cat,
                        "danger": danger,
                        "location": loc,
                        "label": fn
                    }
                    
                    cluster_nodes = {fn}
                    cluster_edges = []

                    # 2. Nút Địa Điểm
                    self.nodes[loc] = {"type": "Location", "label": loc}
                    self.edges.append((fn, loc, "OCCURRED_AT"))
                    cluster_nodes.add(loc)
                    cluster_edges.append((fn, loc, "OCCURRED_AT"))

                    aggressors, victims, interveners = [], [], []
                    prev_event_id = None

                    for idx, ev in enumerate(timeline):
                        ev_code = ev.get("event_id", f"EV_{idx+1:02d}")
                        event_id = f"{fn}_{ev_code}"
                        actor = ev.get("actor_id", "Person_01")
                        target = ev.get("target_id")
                        act_lbl = ev.get("action_label", cat)
                        t_range = f"{ev.get('start_time','00:00')}-{ev.get('end_time','00:00')}"
                        
                        weapon = ev.get("body_part_or_weapon", "Tay không")
                        contact = ev.get("target_contact_point", "Toàn thân")
                        force = ev.get("force_intensity", "Trung bình")
                        impact = ev.get("physical_impact", ev.get("description", ""))
                        leads_to = ev.get("causal_leads_to", "")

                        # 3. Nút Sự Kiện Đa Chiều
                        self.nodes[event_id] = {
                            "type": "Event",
                            "action": act_lbl,
                            "time": t_range,
                            "weapon": weapon,
                            "contact_point": contact,
                            "force_level": force,
                            "impact": impact,
                            "leads_to": leads_to,
                            "video": fn,
                            "category": cat,
                            "actor": actor,
                            "target": target or ""
                        }
                        self.edges.append((fn, event_id, "HAS_EVENT"))
                        cluster_nodes.add(event_id)
                        cluster_edges.append((fn, event_id, "HAS_EVENT"))

                        if prev_event_id:
                            edge_rel = "INTERVENES" if "Intervener" in actor else "LEADS_TO"
                            self.edges.append((prev_event_id, event_id, edge_rel))
                            cluster_edges.append((prev_event_id, event_id, edge_rel))
                        prev_event_id = event_id

                        # 4. Nút Thực Thể & Quan Hệ Tương Tác
                        actor_id = f"{fn}_{actor}"
                        self.nodes[actor_id] = {"type": "Person", "role": actor, "video": fn}
                        self.edges.append((fn, actor_id, "INVOLVES_PERSON"))
                        self.edges.append((actor_id, event_id, f"PERFORMS_{weapon.upper().replace(' ', '_')}"))
                        cluster_nodes.add(actor_id)
                        cluster_edges.extend([(fn, actor_id, "INVOLVES_PERSON"), (actor_id, event_id, "PERFORMS")])
                        
                        if "Aggressor" in actor: aggressors.append(actor_id)
                        elif "Intervener" in actor or "Guard" in actor: interveners.append(actor_id)

                        if target:
                            target_id = f"{fn}_{target}"
                            self.nodes[target_id] = {"type": "Person", "role": target, "video": fn}
                            self.edges.append((fn, target_id, "INVOLVES_PERSON"))
                            self.edges.append((event_id, target_id, f"IMPACTS_{contact.upper().replace(' ', '_')}"))
                            cluster_nodes.add(target_id)
                            cluster_edges.extend([(fn, target_id, "INVOLVES_PERSON"), (event_id, target_id, "IMPACTS")])
                            victims.append(target_id)

                    for agg in aggressors:
                        for vic in victims:
                            self.edges.append((agg, vic, "ATTACKS"))
                            cluster_edges.append((agg, vic, "ATTACKS"))
                    for itv in interveners:
                        for agg in aggressors:
                            self.edges.append((itv, agg, "INTERVENES"))
                            cluster_edges.append((itv, agg, "INTERVENES"))

                    self.video_clusters[fn] = {
                        "category": cat,
                        "nodes": cluster_nodes,
                        "edges": cluster_edges
                    }
            except Exception:
                pass

    def get_graph_summary(self):
        return {"total_nodes": len(self.nodes), "total_edges": len(self.edges)}

    # ===== [NÂNG CẤP] QUERY RAG ĐA CHIỀU =====
    def _expand_query_keywords(self, query_str):
        """Mở rộng từ khóa tìm kiếm bằng từ đồng nghĩa."""
        q_lower = query_str.lower()
        expanded = set(re.findall(r'\w+', q_lower))
        for key, synonyms in KEYWORD_SYNONYMS.items():
            for syn in synonyms:
                if syn in q_lower:
                    expanded.update(synonyms)
                    break
        return expanded

    def _score_text_match(self, text, keywords):
        """Tính điểm khớp giữa text và tập từ khóa."""
        if not text:
            return 0
        t_lower = text.lower()
        score = 0
        for kw in keywords:
            if kw in t_lower:
                score += 1
        return score

    def query_rag(self, query_str, top_k=5):
        """Tìm kiếm đa chiều trên toàn bộ đồ thị tri thức.
        
        Tìm trên:
        - Video: category, location
        - Event: action, weapon, contact_point, force_level, impact, leads_to
        - Person: role (aggressor, victim, intervener)
        
        Returns: Danh sách video kèm chi tiết sự kiện khớp, sắp xếp theo độ liên quan.
        """
        keywords = self._expand_query_keywords(query_str)
        q_lower = query_str.lower()
        
        # Bước 1: Chấm điểm từng video dựa trên TẤT CẢ node liên quan
        video_scores = {}  # {video_name: {"score": int, "matched_events": [...], "video_data": {...}}}
        
        for nid, nd in self.nodes.items():
            ntype = nd.get("type")
            
            # --- Chấm điểm Event Node ---
            if ntype == "Event":
                video_name = nd.get("video", "")
                if not video_name:
                    continue
                    
                ev_score = 0
                matched_fields = []
                
                # Tìm trong hành động
                action_score = self._score_text_match(nd.get("action", ""), keywords)
                if action_score > 0:
                    ev_score += action_score * 3
                    matched_fields.append(f"Hành động: {nd.get('action')}")
                
                # Tìm trong vũ khí/bộ phận
                weapon_score = self._score_text_match(nd.get("weapon", ""), keywords)
                if weapon_score > 0:
                    ev_score += weapon_score * 4  # Trọng số cao vì rất cụ thể
                    matched_fields.append(f"Vũ khí: {nd.get('weapon')}")
                
                # Tìm trong điểm va chạm
                contact_score = self._score_text_match(nd.get("contact_point", ""), keywords)
                if contact_score > 0:
                    ev_score += contact_score * 4
                    matched_fields.append(f"Va chạm: {nd.get('contact_point')}")
                
                # Tìm trong cường độ lực
                force_score = self._score_text_match(nd.get("force_level", ""), keywords)
                if force_score > 0:
                    ev_score += force_score * 2
                    matched_fields.append(f"Lực: {nd.get('force_level')}")
                
                # Tìm trong hệ quả vật lý
                impact_score = self._score_text_match(nd.get("impact", ""), keywords)
                if impact_score > 0:
                    ev_score += impact_score * 2
                    matched_fields.append(f"Hệ quả: {nd.get('impact', '')[:60]}")
                
                # Tìm trong nhân quả
                leads_score = self._score_text_match(nd.get("leads_to", ""), keywords)
                if leads_score > 0:
                    ev_score += leads_score * 1
                    matched_fields.append(f"Nhân quả: {nd.get('leads_to', '')[:60]}")
                
                # Tìm trong category
                cat_score = self._score_text_match(nd.get("category", ""), keywords)
                if cat_score > 0:
                    ev_score += cat_score * 2
                
                if ev_score > 0:
                    if video_name not in video_scores:
                        video_scores[video_name] = {"score": 0, "matched_events": [], "video_data": {}}
                    video_scores[video_name]["score"] += ev_score
                    video_scores[video_name]["matched_events"].append({
                        "event_id": nid,
                        "time": nd.get("time", ""),
                        "action": nd.get("action", ""),
                        "actor": nd.get("actor", ""),
                        "target": nd.get("target", ""),
                        "weapon": nd.get("weapon", ""),
                        "contact_point": nd.get("contact_point", ""),
                        "force_level": nd.get("force_level", ""),
                        "impact": nd.get("impact", ""),
                        "leads_to": nd.get("leads_to", ""),
                        "matched_fields": matched_fields,
                        "relevance_score": ev_score
                    })
            
            # --- Chấm điểm Video Node ---
            elif ntype == "Video":
                vid_score = 0
                cat = nd.get("category", "")
                loc = nd.get("location", "")
                
                cat_score = self._score_text_match(cat, keywords)
                if cat_score > 0:
                    vid_score += cat_score * 3
                
                loc_score = self._score_text_match(loc, keywords)
                if loc_score > 0:
                    vid_score += loc_score * 2
                
                # Tăng điểm video nguy hiểm nếu query liên quan bạo lực
                danger = nd.get("danger", 1)
                if danger >= 6 and any(k in q_lower for k in ["nguy hiểm", "bạo lực", "mạnh", "nghiêm trọng"]):
                    vid_score += 3
                
                if vid_score > 0:
                    if nid not in video_scores:
                        video_scores[nid] = {"score": 0, "matched_events": [], "video_data": {}}
                    video_scores[nid]["score"] += vid_score
                    video_scores[nid]["video_data"] = {
                        "category": cat,
                        "location": loc,
                        "danger_score": danger
                    }
            
            # --- Chấm điểm Person Node ---
            elif ntype == "Person":
                role = nd.get("role", "")
                video_name = nd.get("video", "")
                person_score = 0
                
                if "aggressor" in q_lower and "Aggressor" in role:
                    person_score += 3
                if "victim" in q_lower or "nạn nhân" in q_lower:
                    if "Victim" in role:
                        person_score += 3
                if "can ngăn" in q_lower or "intervener" in q_lower:
                    if "Intervener" in role:
                        person_score += 3
                
                role_score = self._score_text_match(role, keywords)
                person_score += role_score
                
                if person_score > 0 and video_name:
                    if video_name not in video_scores:
                        video_scores[video_name] = {"score": 0, "matched_events": [], "video_data": {}}
                    video_scores[video_name]["score"] += person_score

        # Bước 2: Bổ sung video_data cho các video chưa có
        for vname in video_scores:
            if not video_scores[vname]["video_data"] and vname in self.nodes:
                vnd = self.nodes[vname]
                video_scores[vname]["video_data"] = {
                    "category": vnd.get("category", ""),
                    "location": vnd.get("location", ""),
                    "danger_score": vnd.get("danger", 1)
                }

        # Bước 3: Sắp xếp sự kiện trong mỗi video theo relevance
        for vname in video_scores:
            video_scores[vname]["matched_events"].sort(
                key=lambda x: x.get("relevance_score", 0), reverse=True
            )

        # Bước 4: Sắp xếp video theo tổng điểm, trả về top_k
        sorted_results = sorted(
            [{"video": k, **v} for k, v in video_scores.items()],
            key=lambda x: x["score"],
            reverse=True
        )[:top_k]

        return sorted_results


kg_rag_engine = KnowledgeGraphRAGEngine()