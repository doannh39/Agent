﻿import os
import io
import cv2
import zipfile
import tempfile

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Cấu hình 16 danh mục hành động
DATASETS = [
    {"name": "Punching", "candidate_dirs": [r"E:\test\Punching"]},
    {"name": "Kicking", "candidate_dirs": [r"E:\test\Kicking"]},
    {"name": "Slapping", "candidate_dirs": [r"E:\test\Slapping"]},
    {"name": "Pushing_Shoving", "candidate_dirs": [r"E:\test\Pushing or Shoving"]},
    {"name": "Hair_pulling", "candidate_dirs": [r"E:\test\Hair pulling"]},
    {"name": "Wrestling_down", "candidate_dirs": [r"E:\test\Wrestling down or Throwing to the ground"]},
    {"name": "Group_fighting", "candidate_dirs": [r"E:\test\Group fighting or Mob beating"]},
    {"name": "Threatening_weapon", "candidate_dirs": [r"E:\test\Threatening with a dangerous weapon"]},
    {"name": "Walking", "candidate_dirs": [r"E:\test\Walking"]},
    {"name": "Jogging_Running", "candidate_dirs": [r"E:\test\Jogging or Running"]},
    {"name": "Playing_sports", "candidate_dirs": [r"E:\test\Playing sports"]},
    {"name": "Dancing", "candidate_dirs": [r"E:\test\Dancing"]},
    {"name": "Handshaking", "candidate_dirs": [r"E:\test\Handshaking"]},
    {"name": "Peaceful_gathering", "candidate_dirs": [r"E:\test\Peaceful gathering"]},
    {"name": "Standing_still", "candidate_dirs": [r"E:\test\Standing still"]},
    {"name": "Sitting", "candidate_dirs": [r"E:\test\Sitting"]}
]

def cut_clip_opencv(input_path, output_path, start_sec, end_sec):
    cap = cv2.VideoCapture(input_path)
    if not cap.isOpened():
        return False
        
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    start_frame = int(start_sec * fps)
    end_frame = int(end_sec * fps)
    
    cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
    
    curr_frame = start_frame
    while curr_frame < end_frame:
        ret, frame = cap.read()
        if not ret:
            break
        out.write(frame)
        curr_frame += 1
        
    cap.release()
    out.release()
    return True

def generate_standard_clips_zip(video_path, clip_duration=2.0, stride=1.0):
    """Cắt clips chuẩn khoa học theo cửa sổ trượt 50% overlap và đóng gói ZIP bytes."""
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return None
        
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    total_frames = cap.get(cv2.CAP_PROP_FRAME_COUNT)
    T = total_frames / fps if fps > 0 else 0.0
    cap.release()
    
    if T < clip_duration:
        return None
        
    intervals = []
    curr_start = 0.0
    while curr_start + clip_duration <= T + 0.05:
        curr_end = min(curr_start + clip_duration, T)
        intervals.append((curr_start, curr_end))
        curr_start += stride
        
    if not intervals:
        intervals.append((0.0, T))
        
    zip_buffer = io.BytesIO()
    v_title = os.path.splitext(os.path.basename(video_path))[0]
    
    with tempfile.TemporaryDirectory() as tmp_dir:
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
            for idx, (s_sec, e_sec) in enumerate(intervals):
                clip_filename = f"{v_title}_c{idx+1:03d}_{s_sec:.1f}s-{e_sec:.1f}s.mp4"
                tmp_clip_path = os.path.join(tmp_dir, clip_filename)
                
                if cut_clip_opencv(video_path, tmp_clip_path, s_sec, e_sec):
                    zip_file.write(tmp_clip_path, arcname=clip_filename)
                    
    zip_buffer.seek(0)
    return zip_buffer.getvalue()

def run_scientific_splitter(clip_duration=2.0, stride=1.0):
    print("\n=================================================================")
    print(f"🚀 BẮT ĐẦU CẮT THEO CHUẨN KHOA HỌC (Window: {clip_duration}s | Stride: {stride}s | Overlap: 50%)")
    print("=================================================================")

    grand_total = 0
    scanned_dirs = set()
    
    for ds in DATASETS:
        ds_name = ds["name"]
        video_dir = None
        for p in ds["candidate_dirs"]:
            if os.path.exists(p) and any(f.lower().endswith('.mp4') for f in os.listdir(p)):
                video_dir = p
                break
                
        if not video_dir or video_dir in scanned_dirs:
            continue

        scanned_dirs.add(video_dir)
        out_dir = os.path.join(BASE_DIR, "Clips_Output", ds_name, f"Scientific_{int(clip_duration)}s_Clips")
        os.makedirs(out_dir, exist_ok=True)
        
        video_files = [f for f in os.listdir(video_dir) if f.lower().endswith('.mp4')]
        print(f"\n📂 Đang xử lý danh mục: [{ds_name}] ({len(video_files)} video từ `{video_dir}`)")
        
        dataset_clips = 0
        for v_idx, file_name in enumerate(video_files, 1):
            video_path = os.path.join(video_dir, file_name)
            v_title = os.path.splitext(file_name)[0]
            
            cap = cv2.VideoCapture(video_path)
            fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
            total_frames = cap.get(cv2.CAP_PROP_FRAME_COUNT)
            T = total_frames / fps if fps > 0 else 0.0
            cap.release()
            
            if T < clip_duration:
                continue
                
            intervals = []
            curr_start = 0.0
            while curr_start + clip_duration <= T + 0.05:
                curr_end = min(curr_start + clip_duration, T)
                intervals.append((curr_start, curr_end))
                curr_start += stride
                
            for idx, (s_sec, e_sec) in enumerate(intervals):
                clip_name = f"{v_title}_c{idx+1:03d}_{s_sec:.1f}s-{e_sec:.1f}s.mp4"
                clip_path = os.path.join(out_dir, clip_name)
                
                if os.path.exists(clip_path):
                    dataset_clips += 1
                    continue
                    
                if cut_clip_opencv(video_path, clip_path, s_sec, e_sec):
                    dataset_clips += 1
                    
        print(f"  ✅ Hoàn tất [{ds_name}]: {dataset_clips} clips hợp lệ -> `{out_dir}`")
        grand_total += dataset_clips

    print(f"\n🎯 TỔNG KẾT: Hoàn thành toàn bộ {grand_total} clips chuẩn khoa học!")

if __name__ == "__main__":
    run_scientific_splitter(clip_duration=2.0, stride=1.0)
